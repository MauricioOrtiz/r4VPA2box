#=======================================================================================
#
#   This is a data frame of the tables and plots produces by the r-package.
#   
#    As data.frame, these are used by the html function to plot and put legends in each table plot
#    If new plots/tables are to be created or deprecated User need to update this data frames.
#    Each one is save as png or html table in the "plots" directory. 
#                                                                     M. Ortiz 2017
#=======================================================================================
#'
#'  Create the tables and plots list for html
#'  
#'  Creates two character matrices with the id, names and legends to show of the plots and tables generated and that will be show
#'  in the html pages
#'  @param NULL
#'  @return a list with two matrices Tables and plots
#'  @export
#'  
Tables_plots <- function(){

Tab_tables <- matrix(
  c("Otbl_1","Names_of VPA files","Table 01: Files of VPA2-BOX run reported","1 Settings",
    "Otbl_2","Settings VPA","Table 02: VPA2-Box general 1 Settings","1 Settings",
    "Otbl_2A","Settings Constraints VPA","Table 02A: VPA2-Box Constraint Settings","1 Settings",
    "Otbl_3","Index_fit statistics", "Table 03: Index of abundande fit summary","4 Indices",
    "Otbl_4","SSB_Rec timeseris", "Table 04: SSB and Recruits time series","7 SSB",
    "Otbl_5","CAA_input matrix", "Table 05: CAA input matrix","2 Inputs",
    "Otbl_6","FAA_output matrix","Table 06: FAA estimated matrix","6 FAA",  
    "Otbl_7","NAA_output matrix", "Table 07: NAA estimated matrix","5 NAA",
    "Otbl_8","Parameter Estimates", "Table 08: Estimates parameters summary","3 Estimates",
    "Otbl_9","FAA_bias_error","Table 09: FAA bias error from bootstrap runs","6 FAA",
    "Otbl_10","NAA_stder_error", "Table 10: NAA stderr from bootsrap runs","5 NAA",
    "Otbl_11","Hessian_matrix","Table 11: Estimated Hessian matrix","3 Estimates"), 
   ncol=4, byrow=TRUE)

Tab_plots <- matrix(
  c("Oplot_1","Input CAA","Fig 01: CAA input by age","2 Inputs",
    "Oplot_2","Input CAA Prop","Fig 01a: CAA proportion by age for each year","2 Inputs",
    "Oplot_4","Fecundity at age","Fig 02: Fecundity at age input","2 Inputs",
    "Oplot_6","Input Index by Year","Fig 03: Available index of abundance by Year","2 Inputs",
    "Oplot_7","Input Index scaled trend","Fig 03a: Index of abundance (scaled to their mean) trends","2 Inputs",
    "Oplot_8","Input Index with 90P CI","Fig 03b: Index of abundance and Estimates 95 perc CI input","2 Inputs",
    "Oplot_3","Input WAA","Fig 04: Inputs WAA by index","2 Inputs",
    "Oplot_5","Maturity at age","Fig 05: Maturity at age input","2 Inputs",
    "Oplot_16","Par Estimates","Fig 06: Estimated parameters VPA run","3 Estimates",
    "Oplot_19","Corr plot par estimated","Fig 07: Correlation plot of estimated parameters VPA","3 Estimates",
    "Oplot_20","Hessian matrix","Fig 08: Hessian matrix plot","3 Estimates",
    "Oplot_10b","Index Chisquare","Fig 10: Index fit Chisquare values","4 Indices",
    "Oplot_10c","Index Pred vs Obs fit","Fig 11: Index Predicted and observed values fits","4 Indices",
    "Oplot_10a","Index Residuals ts","Fig 11a: Index Residuals time series","4 Indices",
    "Oplot_10","Index Pred vs Obs ts","Fig 11b: Predicted and observer Indices of abundance time series","4 Indices",
    "Oplot_11","Index Selectivity","Fig 12: Index Selectivity by Age and Year","4 Indices",
    "Oplot_23","Index fit CI ribbon","Fig 13: Index of abundance fits with 90 per CI bootstrap runs","4 Indices",
    "Oplot_9","Index loglikelihood","Fig 09: Index of abundance fit log likelihood VPA","4 Indices",
    "Oplot_9a","Index LL and deviance","Fig 09a: Index of abundance fit log likelihood and size proportional to deviance","4 Indices",
    "Oplot_13","CAA inp vrs out","Fig 14: Comparison of total removals (CAA) input and output","5 NAA",
    "Oplot_15","NAA by age ts","Fig 15: NAA by age time series","5 NAA",
    "Oplot_15a","NAA by Age bubble plot","Fig 16: NAA by age-year bubble plot","5 NAA",
    "Oplot_21a","NAA by age CI ribbon","Fig 17: NAA and 90 per CI by age","5 NAA",
    "Oplot_21","NAA by age CI ts","Fig 17a: NAA and 90 perc CI from boostrap runs","5 NAA",
    "Oplot_21b","SSB CI ts","Fig 17b: SSB and 90 perc CI from boostrap runs","7 SSB",
    "Oplot_21c","SSB CI ts","Fig 17c: SSB and 90 perc CI from boostrap runs","7 SSB",
    "Oplot_18","NAA stderr bubble plot","Fig 17b: NAA stderr bubble plot from bootstrap runs","5 NAA",
    "Oplot_21b","NAA violin plots by age","Fig 18: NAA annual distribution of last 10 years bootstraps by age","5 NAA",
    "Oplot_14","FAA by Age ts","Fig 19: FAA by Age time series","6 FAA",
    "Oplot_14a","FAA by Age bubble plot","Fig 20: FAA by age-year bubble plot","6 FAA",
    "Oplot_22a","FAA by age CI ribbon","Fig 21: FAA and 90 per CI by age","6 FAA",
    "Oplot_22","FAA by age CI ts","Fig 21a: FAA and 90 perc CI from boostrap runs","6 FAA",
    "Oplot_17","FAA bias bubble plot","Fig 21b: FAA bias bubble plot from bootstrap runs","6 FAA",
    "Oplot_22b","FAA violin plots by age","Fig 22: FAA annual distribution of last 10 years bootstraps by age","6 FAA",
    "Oplot_12","SSB ts","Fig 23: Spawning stock biomass (SSB) time series","7 SSB",
    "Oplot_12a","Recruits ts","Fig 24: Recruits time series","7 SSB",
    "Oplot_12b","Rec vs SSB","Fig 25: Scatter plot Recruits vrs SBB ","7 SSB",
    "Oplot_12c","Corr SSB Rec","Fig 26: Scaled to their mean SSB and Rec time series and estimated correlation","7 SSB",
    "Oplot_24","Retrospective SSB","Fig 27: Retrospective trends SSB time series","8 Retro",
    "Oplot_24a","Retrospective Rec","Fig 28: Retrospective trends Recruits time series","8 Retro",
    "Oplot_25","Retrospective FitStats","Fig 29: Retrospective overall Fit statistics","8 Retro",
    "Oplot_26","Retrospective EstPar","Fig 30: Retrospective trends Parameter Estimates","8 Retro",
    "Oplot_27","Retrospective NAA","Fig 31: Retrospective trends NAA time series","8 Retro",
    "Oplot_28","Retrospective FAA","Fig 32: Retrospective trends FAA time series","8 Retro"),
  ncol=4,byrow = TRUE)
  y = list(Tab_tables=Tab_tables,Tab_plots=Tab_plots)
  return(y)
}
