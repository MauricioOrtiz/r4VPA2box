####################################################################################
#
#  Function to export results to the html type presentation of the VPA2-Box
#     copy and adapted from the r4ss package... need to get permision to use it
#
####################################################################################
#' VPA2Box html results
#'
#' Creates an html page with VPA2 box results
#' @param replist name of csv file with list of figures and tables of vpa results,
#'  plotdir folder where the plots will be stored,
#'  plotInfoTable data frame with list of plots and tables available,
#'  title Name that will be printed in html page
#' @return it call default web browser showing
#' @export
#' trim()

VPA2Box_html  <- function(replist = replist, plotdir = "plots", plotInfoTable = NULL,
          title = "VPA2Box Output", width = 700, openfile = TRUE, multimodel = FALSE,
          filenotes = NULL, verbose = TRUE)
{
   cat("Running 'VPA2Box_html':\n", "  By default, this function will look in the directory where PNG files were created\n",
       "  for CSV files with the name 'plotInfoTable...' written by 'Plots and summary.'\n",
       "  HTML files are written to link to these plots and put in the same directory.\n",
       "  Please provide feedback on any bugs, annoyances, or suggestions for improvement.\n\n")
   if (is.null(plotInfoTable)) {
      if (!is.null(replist)) {
         dir <- getwd()
         filenames <- dir(file.path(dir, plotdir))
         filenames <- filenames[grep("plotInfoTable", filenames)]
         filenames <- filenames[grep(".csv", filenames)]
         if (length(filenames) == 0) {
            stop("No CSV files with name 'plotInfoTable...'") }
         plotInfoTable <- NULL
         for (ifile in 1:length(filenames)) {
            filename <- file.path(dir, plotdir, filenames[ifile])
            temp <- read.csv(filename, colClasses = "character")
            plotInfoTable <- rbind(plotInfoTable, temp)
         }
         plotInfoTable$png_time <- as.POSIXlt(plotInfoTable$png_time)
         runs <- unique(plotInfoTable$Run_time)
         if (length(runs) > 1) {
            if (multimodel) {
               msg <- c("Warning!: CSV files with name 'plotInfoTable...' are from multiple model runs.\n",
                        "    Hopefully you know what you're doing, or change to 'multimodel=FALSE.\n",
                        "    Runs:\n")
               for (irun in 1:length(runs)) msg <- c(msg,
                                                     paste("    ", runs[irun], "\n"))
               cat(msg)
            } else {
               msg <- c("CSV files with name 'plotInfoTable...' are from multiple model runs.\n",
                        "    Delete old files or (if you really know what you're doing) override with 'multimodel=TRUE.\n",
                        "    Runs:\n")
               for (irun in 1:length(runs)) msg <- c(msg,
                                                     paste("    ", runs[irun], "\n"))
               stop(msg)
            }
         }
         filetable <- table(plotInfoTable$file)
         duplicates <- names(filetable[filetable > 1])
         if (length(duplicates) > 0) {
            if (verbose)
               cat("Removing duplicate rows in combined plotInfoTable based on mutliple CSV files\n")
            for (idup in 1:length(duplicates)) {
               duprows <- grep(duplicates[idup], plotInfoTable$file,
                               fixed = TRUE)
               duptimes <- plotInfoTable$png_time[duprows]
               dupbad <- duprows[duptimes != max(duptimes)]
               goodrows <- setdiff(1:nrow(plotInfoTable),
                                   dupbad)
               plotInfoTable <- plotInfoTable[goodrows, ]
            }
         }
      }  else {
         stop("Need input for 'replist' or 'plotInfoTable'")
      }
   }
   if (!is.data.frame(plotInfoTable)) {
      stop("'plotInfoTable' needs to be a data frame") }
   plotInfoTable$basename <- basename(as.character(plotInfoTable$file))
   plotInfoTable$dirname <- dirname(as.character(plotInfoTable$file))
   plotInfoTable$dirname2 <- basename(dirname(as.character(plotInfoTable$file)))
   plotInfoTable$path <- file.path(plotInfoTable$dirname2, plotInfoTable$basename)
   dir <- dirname(plotInfoTable$dirname)[1]
   categories <- unique(plotInfoTable$category)
   for (icat in 0:length(categories)) {
      if (icat == 0) {
         category <- "Home"
         htmlfile <- file.path(dir, plotdir, "VPA2Box_output.html")
         htmlhome <- htmlfile
         if (verbose) {
            cat("Home HTML file with output will be:\n",
                htmlhome, "\n")
         }
      } else {
         category <- categories[icat]
         htmlfile <- file.path(dir, plotdir, paste("VPA2Box_output_",
                                                   category, ".html", sep = ""))    }
      cat("<html><head><title>", title, "</title>\n", "    <!-- source for text below is http://unraveled.com/publications/css_tabs/ -->\n",
          "    <!-- CSS Tabs is licensed under Creative Commons Attribution 3.0 - http://creativecommons.org/licenses/by/3.0/ -->\n",
          "    \n", "    <style type=\"text/css\">\n", "    \n",
          "    body {\n", "    font: 100% verdana, arial, sans-serif;\n",
          "    background-color: #fff;\n", "    margin: 50px;\n",
          "    }\n", "    \n", "    /* begin css tabs */\n",
          "    \n", "    ul#tabnav { /* general settings */\n",
          "    text-align: left; /* set to left, right or center */\n",
          "    margin: 1em 0 1em 0; /* set margins as desired */\n",
          "    font: bold 11px verdana, arial, sans-serif; /* set font as desired */\n",
          "    border-bottom: 1px solid #6c6; /* set border COLOR as desired */\n",
          "    list-style-type: none;\n", "    padding: 3px 10px 2px 10px; /* THIRD number must change with respect to padding-top (X) below */\n",
          "    }\n", "    \n", "    ul#tabnav li { /* do not change */\n",
          "    display: inline;\n", "    }\n", "    \n", "    body#tab1 li.tab1, body#tab2 li.tab2, body#tab3 li.tab3, body#tab4 li.tab4 { /* settings for selected tab */\n",
          "    border-bottom: 1px solid #fff; /* set border color to page background color */\n",
          "    background-color: #fff; /* set background color to match above border color */\n",
          "    }\n", "    \n", "    body#tab1 li.tab1 a, body#tab2 li.tab2 a, body#tab3 li.tab3 a, body#tab4 li.tab4 a { /* settings for selected tab link */\n",
          "    background-color: #fff; /* set selected tab background color as desired */\n",
          "    color: #000; /* set selected tab link color as desired */\n",
          "    position: relative;\n", "    top: 1px;\n", "    padding-top: 4px; /* must change with respect to padding (X) above and below */\n",
          "    }\n", "    \n", "    ul#tabnav li a { /* settings for all tab links */\n",
          "    padding: 2px 4px; /* set padding (tab size) as desired; FIRST number must change with respect to padding-top (X) above */\n",
          "    border: 1px solid #6c6; /* set border COLOR as desired; usually matches border color specified in #tabnav */\n",
          "    background-color: #cfc; /* set unselected tab background color as desired */\n",
          "    color: #666; /* set unselected tab link color as desired */\n",
          "    margin-right: 0px; /* set additional spacing between tabs as desired */\n",
          "    text-decoration: none;\n", "    border-bottom: none;\n",
          "    }\n", "    \n", "    ul#tabnav a:hover { /* settings for hover effect */\n",
          "    background: #fff; /* set desired hover color */\n",
          "    }\n", "    \n", "    /* end css tabs */\n",
          "    \n", "    \n", "    h2 {\n", "    font-size: 20px;\n",
          "    color: #4c994c;\n", "    padding-top: 1px;\n",
          "    font-weight: bold;\n", "    border-bottom-width: 1px;\n",
          "    border-bottom-style: solid;\n", "    border-bottom-color: #6c6;\n",
          "    padding-bottom: 2px;\n", "    padding-left: 0px;\n",
          "    }\n", "    </style>", "</head>\n", sep = "",
          file = htmlfile, append = FALSE)
      cat("<!-- Site navigation menu -->\n", "  <ul id=\"tabnav\">\n",
          file = htmlfile, append = TRUE)
      for (itab in 0:length(categories)) {
         if (itab == 0) {
            tab <- "Home"
            cat("    <li class=\"tab1\"><a href=\"VPA2Box_output.html\">Home</a></li>\n",
                sep = "", file = htmlfile, append = TRUE)
         }  else {
            tab <- categories[itab]
            cat("    <li class=\"tab", itab + 1, "\"><a href=\"VPA2Box_output_",
                tab, ".html\">", tab, "</a></li>\n", sep = "",
                file = htmlfile, append = TRUE)  }
      }
      cat("  </ul>\n", file = htmlfile, append = TRUE)
      if (category == "Home") {
         cat("\n\n<h2><a name=\"", category, "\">", category,
             "</h2>\n", sep = "", file = htmlfile, append = TRUE)
         if (is.null(replist)) {
            cat("<p>Model info not available (need to supply \"replist\" input to VPA2Box_HTML function)</p>\n",
                sep = "", file = htmlfile, append = TRUE)
         }  else {
            cat("<p><b>VPA2-Box Run Summary:</b>\n", replist$VPA2Box_ver, "   C. Porch NOAA/NMFS",
                "</p>\n\n", "<p><b>Title Run:</b>\n", replist$Title_run, "</p>\n\n", "<p><b>Date-time of model run:</b>\n",
                substring(replist$Date_run, 1), "</p>\n\n",
                sep = "", file = htmlfile, append = TRUE)
            if (!is.null(filenotes)) {
               for (i in 1:length(filenotes)) {
                  cat("<p><b>Notes:</b>\n", paste(filenotes,
                                                  collapse = "</b>\n"), "</p>\n\n", sep = "",
                      file = htmlfile, append = TRUE)
               }
            }
            nwarn <- replist$Nwarnings
            if (is.na(nwarn)) {
               cat("<p><b>Warnings :</b> NA</p>\n\n",
                   sep = "", file = htmlfile, append = TRUE)
            }
            else {
               if (nwarn == 0) {
                  cat("<p><b>Warnings :</b> None</p>\n\n",
                      sep = "", file = htmlfile, append = TRUE)
               }
               if (nwarn > 0) {
                  if (nwarn <= 20) {
                     cat("<p><b>Warnings :</b></p>\n\n",
                         "<pre>\n", sep = "", file = htmlfile,
                         append = TRUE)
                  }
                  else {
                     cat("<p><b>Warnings :</b></p>\n\n",
                         "<pre>\n", sep = "", file = htmlfile,
                         append = TRUE)
                  }
                  for (irow in 3:length(replist$warnings)) {
                     cat(replist$warnings[irow], "\n", sep = "",
                         file = htmlfile, append = TRUE)
                  }
                  cat("</pre>\n", sep = "", file = htmlfile,
                      append = TRUE)
               }
            }
         }
      }
      else {
         plotinfo <- plotInfoTable[plotInfoTable$category==category, ]
         cat("\n\n<h2><a name=\"", category, "\">", category,
             "</h2>\n", sep = "", file = htmlfile, append = TRUE)
         for (i in 1:nrow(plotinfo)) {
            if(grepl(".html",plotinfo$basename[i])) {
               cat("<p align=left><a href='", plotinfo$basename[i],
                   "'><iframe src='", plotinfo$basename[i], "' border=0 height= 600 width=",
                   width*1.5, "></iframe></a><br>", plotinfo$caption[i], "<br><i><small>file: <a href='",
                   plotinfo$basename[i], "'>", plotinfo$basename[i],
                   "</a></small></i>\n", sep = "", file = htmlfile,
                   append = TRUE)
               # cat("<p align=left><a href='", plotinfo$basename[i],
               #     "'><object data='", plotinfo$basename[i], "' border=0 width=",
               #     width*1.5, "></object></a><br>", plotinfo$caption[i], "<br><i><small>file: <a href='",
               #     plotinfo$basename[i], "'>", plotinfo$basename[i],
               #     "</a></small></i>\n", sep = "", file = htmlfile,
               #     append = TRUE)
                  }  else {
               cat("<p align=left><a href='", plotinfo$basename[i],
                   "'><img src='", plotinfo$basename[i], "' border=0 width=",
                  width, "></img></a><br>", plotinfo$caption[i], "<br><i><small>file: <a href='",
                  plotinfo$basename[i], "'>", plotinfo$basename[i],
                  "</a></small></i>\n", sep = "", file = htmlfile,
                  append = TRUE) }
            }
      }
   }
   cat("\n\n</body>\n</html>", file = htmlfile, append = TRUE)
   if (openfile) {
      cat("Opening HTML file in your default web-browser.\n")
      htmlhome2 <- file.path(getwd(), htmlhome)
      if (is.na(file.info(htmlhome2)$size)) {
         browseURL(htmlhome)
      } else {
         browseURL(htmlhome2) }
   }
}
