#========================================================================================================#
#
# Script to import all the VPA2Box files getting the setting from the control and data file 
#  VPA2Box  by Clay Porch  version.
#  This script get objects and plots similar to GUI version from the NFT tool box
#            MORTIZ  Aug 2017
#
#  Notes:
#  Make the necessary changes in this portion of the script, where, what years, etc.
#      This script exclude the BENCH-k.OUT, SR_PARMS.OUT and Fcurr-k.OUT (different format)
#
#========================================================================================================#

CodeGetVPA2box <- function(dirVPA,vpa_ctl,...) {

#=================================================================================
#
#  Reading the Control Data file 
#
#=================================================================================

tmp = readLines(vpa_ctl)
tmp2 = regexpr("Version",tmp[2], ignore.case = TRUE)[1]
vpa_version = trimws(substr(tmp[2],start=tmp2,stop=(tmp2+15)))

tmp = tmp[-grep("#",substr(tmp,1,3),fixed = FALSE)]
vpa_files = as.list(trim(substr(tmp[1:7],start=1,stop=50)))
vpa_files = matrix(gsub("'","",vpa_files),ncol=1)
row.names(vpa_files) = c("Title run","Data input file", "Par input file", "Results file", "Par est file", "Sheet file", "Taggind data")

vpa_Files = list(VPA2BOX_ver=vpa_version,Control_file=vpa_ctl,vpa_files=vpa_files,vpa_dir=dirVPA)



Otbl_1 <- datatable((vpa_files),options=list(dom='t',pageLength = 8),colnames = c("File name"),style="default",
                    caption = "Table 1: Files of VPA2-BOX run reported")

vpa_n_zones = as.numeric(unlist(split_str(trim(tmp[8])))[1])
vpa_2_type = if(vpa_n_zones>1) {
   vpa_2_type = as.numeric(substr(tmp[9],2,2))}

#  Here need to update code IF Tagging data is going to be used ...

vpa_tagging = as.numeric(unlist(split_str(trim(tmp[10]))))
if(vpa_tagging [1] > 0) {
   tagg_data = TRUE
   tagg_wgt_ObjFunc = vpa_tagging[2]
   tagg_timig = vpa_tagging[-(1:2)]
} else {
   tagg_data = FALSE
}

vpa_rand_seed = as.numeric(unlist(split_str(trim(tmp[11])))[1])

vpa_max_N_amoeba = as.numeric(unlist(split_str(trim(tmp[12])))[1])

vpa_n_constarts = as.numeric(unlist(split_str(trim(tmp[13])))[1])

vpa_PDEV = as.numeric(unlist(split_str(trim(tmp[14])))[1])

vpa_search_alg_ctrl = rbind(vpa_rand_seed,vpa_max_N_amoeba,vpa_n_constarts,vpa_PDEV)
row.names(vpa_search_alg_ctrl)=c("Random seed","N Amoeba","N Starts","PDEV")

vpa_index_wgt = rbind(as.numeric(unlist(split_str(trim(tmp[15])))[1]),as.numeric(unlist(split_str(trim(tmp[16])))[1]),as.numeric(unlist(split_str(trim(tmp[17])))[1]))
row.names(vpa_index_wgt) = c("Scale","Weighting","Variance scale factor")

if (as.numeric(unlist(split_str(trim(tmp[18])))[1])> 0) {
   vpa_constr_vulnerability = matrix(as.numeric(unlist(split_str(trim(tmp[18]))))[1:4],ncol=1)
   rownames(vpa_constr_vulnerability) = c("N yrs penalty", "Stdev severity penalty", "1st age penalty", "last age penalty")
} else {
   vpa_constr_vulnerability = matrix(0,ncol=1)
   rownames(vpa_constr_vulnerability) = c("N yrs penalty")
}

if (as.numeric(unlist(split_str(trim(tmp[19])))[1])> 0) {
   vpa_constr_recruitment = matrix(as.numeric(unlist(split_str(trim(tmp[19])))[1:2]),ncol=1)
} else {
   vpa_constr_recruitment = matrix(c(0,NA),ncol=1) 
}

if (as.numeric(unlist(split_str(trim(tmp[20])))[1])>0) {
   vpa_link_rec2stocks = matrix(as.numeric(unlist(split_str(trim(tmp[20])))[1:3]),ncol=1)
}  else {
   vpa_link_rec2stocks = matrix(c(0,NA,NA),ncol=1)
} 

   rownames(vpa_constr_recruitment) = c("Apply penalty N yrs ", "Stdev severity penalty")
   rownames(vpa_link_rec2stocks) = c("Apply penalty N yrs ", "Stdev severity penalty", "Recruitment ratio")

vpa_constr_StockRecruit = matrix(as.numeric(unlist(split_str(trim(tmp[21])))[1:3]),ncol=1)
rownames(vpa_constr_StockRecruit) = c("PDF Spawner-Rec penalty","First yr","Last yr")

vpa_parameter_est_opt = matrix(c(as.numeric(unlist(split_str(trim(tmp[22])))[1]),as.numeric(unlist(split_str(trim(tmp[23]))))[1]),ncol=1)
row.names(vpa_parameter_est_opt) = c("Pars estimated","Estimation of Qs")

vpa_bootstrap = matrix(as.numeric(unlist(split_str(trim(tmp[24])))[1:3]),ncol=1)
rownames(vpa_bootstrap) = c("Number boots", "Stine correction", "Output type file")

vpa_retrospective = as.numeric(unlist(split_str(trim(tmp[25])))[1])
names(vpa_retrospective) = c("N yrs retrospective")

vpa_gen_settings = list(VPA_Areas=vpa_n_zones,VPA_2Box_Type=ifelse(vpa_n_zones>1,"Two stock","One stock"),Vpa_Tagging=ifelse(vpa_tagging[1]>0,"Yes","No"),Random_seed=vpa_rand_seed,N_amoeba=vpa_max_N_amoeba,Vpa_starts=vpa_n_constarts,PDEV=vpa_PDEV,Pars_estimated=ifelse(vpa_parameter_est_opt[1]==1,"Fs terminal","N age terminal"),Q_estimates=ifelse(vpa_parameter_est_opt[2]<1,"MLE concentrated","Estimated"),Bootstrap=if(vpa_bootstrap[1]>0){c("Yes",vpa_bootstrap[1])} else {"No"},Retrospective=if(vpa_retrospective[1]>0) {c("Yes",vpa_retrospective[1])} else {"No"})

vpa_constrainst = list(Index_wgt=vpa_index_wgt,Vulnerability=vpa_constr_vulnerability,Recruitment=vpa_constr_recruitment,Rec2stocks=vpa_link_rec2stocks,Stock_Rec=vpa_constr_StockRecruit)

tmp <- data.frame(Setting = names(vpa_gen_settings), Value = as.character(unlist(lapply(vpa_gen_settings,"[[",1))))
Otbl_2 <- datatable(tmp,options=list(pageLength=15),rownames=FALSE,caption='Table 2: VPA2-Box general settings',width = 440)

tmp <- as.data.frame(cbind(Setting = rep(unlist(names(vpa_constrainst)),times=as.numeric(unlist(lapply(vpa_constrainst,length)))), Constraint = unlist(lapply(vpa_constrainst,rownames)),Value = unlist(vpa_constrainst)))
Otbl_2A <- datatable(tmp,options=list(pageLength=15),rownames=FALSE,caption='Table 2a: VPA2-Box constraint settings',width = 640)


#  pending:  to present general settings vpa and constraints as table in html version...



#=================================================================================
#
#     Now read the input Data file 
#
#=================================================================================

if(!file.exists(vpa_files["Data input file",])) {
  x = paste("Error VPA data input file doesn't exit, please check name and location.")
  stop(x) }

tmp = readLines(vpa_files["Data input file",])
tmp = tmp[-grep("#",tmp,ignore.case = FALSE)]
tmp = trim(gsub("\t", " ", tmp, perl = TRUE))

vpa_years = as.numeric(unlist(split_str(tmp[1]))[1:2])
names(vpa_years) = c("first_yr","last_yr")
num_years = as.numeric(vpa_years["last_yr"] - vpa_years["first_yr"] + 1)
vpa_ages = as.numeric(unlist(split_str(tmp[2]))[1:4])
names(vpa_ages) = c("first_age","last_age","plus_age","expand_plus")
num_ages = as.numeric(vpa_ages["last_age"]- vpa_ages["first_age"] + 1)
num_indices = as.numeric(unlist(split_str(tmp[3]))[1])

spawn_season = as.numeric(unlist(split_str(tmp[4]))[1])
maturity_age = as.numeric(unlist(split_str(tmp[5]))[seq(vpa_ages["first_age"],vpa_ages["last_age"])])
names(maturity_age) = paste("Age",seq(vpa_ages["first_age"],vpa_ages["last_age"]))

tmp2 = unlist(gregexpr("'",tmp[6]))
vpa_catch_zone = substring(tmp[6],tmp2[1],tmp2[2])
vpa_catch_setting = as.numeric(unlist(split_str(trim(substr(tmp[6],tmp2[2]+1,100)))))
names(vpa_catch_setting) = c("PDF of catch","sigma catch")

####################################
# read now the CAA 
####################################

CAA_matrix = matrix(NA,ncol=(vpa_ages["last_age"]-vpa_ages["first_age"]+1),nrow=(vpa_years[2]-vpa_years[1]+1))
colnames(CAA_matrix)= paste("Age",seq(vpa_ages["first_age"],vpa_ages["last_age"]))
rownames(CAA_matrix)= seq(vpa_years[1],vpa_years[2])

for (i in 1:(vpa_years[2]-vpa_years[1]+1)){
  tmp2 = as.numeric(unlist(split_str(trim(tmp[i+6]))))
  if(tmp2[1]!=as.numeric(row.names(CAA_matrix)[i])){
    paste("Error VPA data input CAA years doesn't match, please check.")
    stop()  }
  CAA_matrix[i,] = tmp2[-1]
} 

####################################
# read now the Indices of abundance 
####################################

Index_specification = matrix(NA,nrow=num_indices,ncol=7)
Index_matrix = matrix(NA,ncol=num_indices,nrow=(vpa_years[2]-vpa_years[1]+1))
row.names(Index_matrix) = seq(vpa_years[1],vpa_years[2])
Index_CV_matrix = Index_matrix
Index_names = matrix(NA,nrow=num_indices,ncol=1)
rowtmp = 6 + num_years + 1  # line with -1 indicating end of CAA input


for (i in 1:num_indices){
  tmp2 = unlist(split_str(trim(tmp[rowtmp + i])))
  Index_specification[i,] = as.numeric(tmp2[1:7])
  tmp3 = as.numeric(gregexpr("\'",tmp[rowtmp + i])[[1]])
  if(tmp3[1] < 0) {
     paste("Error:  Index names must be enclosed with single quotes! Revise VPA data file")
     stop()}
  Index_names[i,1] = substr(tmp[rowtmp + i],tmp3[1],tmp3[2])
}

rownames(Index_specification) = Index_names[,1]
colnames(Index_specification) = c("Index ID","Index pdf","Units","Vulnerability","Timing","First Age","Last Age")

rowtmp = (rowtmp + i + 1)
tmp3 = i = 1

# find the lines that have the index values by Index ID and year.

while(tmp3 > 0) {
   tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp + i])))[1])
   i = i + 1
   next
}

rowtmp = c((rowtmp + 1), (rowtmp + i - 2))

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
for(i in 1:length(tmp2)){
   tmp3 = as.numeric(unlist(split_str(trim(tmp2[i]))))
   Index_matrix[(tmp3[2]-vpa_years[1]+1),tmp3[1]] = tmp3[3]
   Index_CV_matrix[(tmp3[2]-vpa_years[1]+1),tmp3[1]] = tmp3[4]
}

Index_matrix = ifelse(Index_matrix < 0,NA,Index_matrix) 
Index_CV_matrix = ifelse(Index_CV_matrix < 0,NA,Index_CV_matrix) 

#######################################
# read now the Indices selectivities 
#######################################

Index_selectivity = matrix(NA,ncol = (2+vpa_ages["last_age"]-vpa_ages["first_age"]+1),nrow = num_indices*(vpa_years[2]-vpa_years[1]+1))
colnames(Index_selectivity) = c("Index_ID","Year",paste("Age",seq(vpa_ages["first_age"],vpa_ages["last_age"])))
Index_selectivity = data.frame(Index_selectivity)

tmp3 = i = 1
rowtmp[1] = rowtmp[2] + 1  # line with -1 end of index data  
   
while(tmp3 > 0) {
  rowtmp[2] = rowtmp[1] + i
  tmp2 = as.numeric(unlist(split_str(trim(tmp[rowtmp[2]]))))
  tmp3 = tmp2[1]
  if(tmp3 > 0) {Index_selectivity[i,] = tmp2}
  i = i + 1
  next
}

Index_selectivity = Index_selectivity[!is.na(Index_selectivity$Index_ID),]


###################################################################
# read now the weight at age (WAA) for indices of abundance 
###################################################################

WAA_matrix = matrix(NA,ncol=((2+vpa_ages["last_age"]-vpa_ages["first_age"]+1)),nrow=num_indices*(vpa_years[2]-vpa_years[1]+1))
colnames(WAA_matrix) = c("Index_ID","Year",paste("Age",seq(vpa_ages["first_age"],vpa_ages["last_age"])))
WAA_matrix = data.frame(WAA_matrix)

tmp3 = i = 1
rowtmp[1] = rowtmp[2]   # line with -1 end of index selectivity  

while(tmp3 > 0) {
   rowtmp[2] = rowtmp[1] + i
   tmp2 = as.numeric(unlist(split_str(trim(tmp[rowtmp[2]]))))
   tmp3 = tmp2[1]
   if(tmp3 > 0) {WAA_matrix[i,] = tmp2}
   i = i + 1
   next
}

WAA_matrix = WAA_matrix[!is.na(WAA_matrix$Index_ID),]

#########################################
#  Read Fecundity at Age SSB records 
#########################################

FecAA_matrix = matrix(NA,ncol=((1+vpa_ages["last_age"]-vpa_ages["first_age"]+1)),nrow=1)
colnames(FecAA_matrix) = c("Year",paste("Age",seq(vpa_ages["first_age"],vpa_ages["last_age"])))
FecAA_matrix = data.frame(FecAA_matrix)

tmp3 = i = 1
rowtmp[1] = rowtmp[2]   # line with -1 end of index selectivity  

while(tmp3 > 0) {
   rowtmp[2] = rowtmp[1] + i
   tmp2 = as.numeric(unlist(split_str(trim(tmp[rowtmp[2]]))))
   tmp3 = tmp2[1]
   if(tmp3 > 0) {FecAA_matrix[i,] = tmp2}
   i = i + 1
   next
}


Vpa_Inputs = list(Years=vpa_years,Ages=vpa_ages,Spawn_season=spawn_season,Maturity=maturity_age,Catch_sett=vpa_catch_setting,Indices=Index_specification)
Vpa_Inp_Matrices = list(CAA=CAA_matrix,Index=list(Names=Index_names, Values=Index_matrix,CV=Index_CV_matrix,Selectivity=Index_selectivity),WAA=WAA_matrix,Fecundity=FecAA_matrix)














#=================================================================================
#
#     Now read the input Parameter file 
#
#=================================================================================

if(!file.exists(vpa_files["Par input file",])) {
  x = paste("Error VPA Parameter input file doesn't exit, please check name and location.")
  stop(x) }

tmp = readLines(vpa_files["Par input file",])
tmp = trim(gsub("\t", " ", tmp, perl = TRUE))
tmp = tmp[-grep("#",tmp,ignore.case = FALSE)]
tmp = sub_Dexp(tmp)

#########################################
#  Read Terminal F/N at age PARAMETERS 
#########################################

Par_terminals = matrix(NA, ncol=5, nrow=(num_ages-1))
rowtmp = 1
i = k = 1 

#for (i in 1:(num_ages-1)){
while (i < num_ages){
   alt_format = grepl("\\$",tmp[k],perl=TRUE)
   if(alt_format == FALSE) {
    Par_terminals[i,] = as.numeric(unlist(split_str(trim(tmp[k])))[1:5])
    i = i + 1
     } else {
    tmp3 = as.numeric(unlist(split_str(trim(tmp[k])))[2:7])
    for (j in 1:tmp3[1]){
      Par_terminals[i+j-1,] = tmp3[-1]
    }
    i = i + j
     }
   k = k + 1
   next
}

rowtmp = (k - 1) 
  
#################################
#  Read F-Ratio PARAMETERS 
#################################

Fratio_pars = matrix(NA, ncol=5, nrow = (num_years))
i = k = 1 

while (i <= num_years){
#   print(i,k)
   alt_format = grepl("\\$",tmp[rowtmp[1]+k],perl=TRUE)
   if(alt_format == FALSE) {
      Fratio_pars[i,] = as.numeric(unlist(split_str(trim((tmp[rowtmp[1]+k]))))[1:5])
      i = i + 1
   } else {
      tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp[1]+k])))[2:7])
      for (j in 1:tmp3[1]){
         Fratio_pars[i+j-1,] = tmp3[-1]
      }
      i = i + j
   }
   k = k + 1
   next
}

rowtmp = rowtmp + (k - 1) 

#########################################
#  Read Natural Mortality PARAMETERS 
#########################################

M_pars = matrix(NA, ncol=5, nrow=num_ages)
i = k = 1 

while (i <= num_ages){
   alt_format = grepl("\\$",tmp[rowtmp[1]+k],perl=TRUE)
   if(alt_format == FALSE) {
      M_pars[i,] = as.numeric(unlist(split_str(trim((tmp[rowtmp+k]))))[1:5])
      i = i + 1
   } else {
      tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp[1]+k])))[2:7])
      for (j in 1:tmp3[1]){
         M_pars[i+j-1,] = tmp3[-1]
      }
      i = i + j
   }
   k = k + 1
   next
}

rowtmp = rowtmp + (k - 1) 


############################
#  Read Mixing PARAMETERS 
############################

Mixing_pars = matrix(NA, ncol=5, nrow=num_ages)
i = k = 1 

while (i <= num_ages){
   alt_format = grepl("\\$",tmp[rowtmp[1]+k],perl=TRUE)
   if(alt_format == FALSE) {
      Mixing_pars[i,] = as.numeric(unlist(split_str(trim((tmp[rowtmp+k]))))[1:5])
      i = i + 1
   } else {
      tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp[1]+k])))[2:7])
      for (j in 1:tmp3[1]){
         Mixing_pars[i+j-1,] = tmp3[-1]
      }
      i = i + j
   }
   k = k + 1
   next
}

rowtmp = rowtmp + (k - 1) 

#######################################
#  Read Stock-Recruitment PARAMETERS 
#######################################

SR_pars = matrix(NA, ncol=5, nrow=5)
i = k = 1 

while (i <= 5){
   alt_format = grepl("\\$",tmp[rowtmp[1]+k],perl=TRUE)
   if(alt_format == FALSE) {
      SR_pars[i,] = as.numeric(unlist(split_str(trim((tmp[rowtmp+k]))))[1:5])
      i = i + 1
   } else {
      tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp[1]+k])))[2:7])
      for (j in 1:tmp3[1]){
         SR_pars[i+j-1,] = tmp3[-1]
      }
      i = i + j
   }
   k = k + 1
   next
}

rowtmp = rowtmp + (k - 1) 

#######################################
#  Read Variance Scaling PARAMETERS 
#######################################

VarScal_pars =  matrix(NA, ncol=5, nrow=num_indices)
i = k = 1 

while (i <= num_indices){
   alt_format = grepl("\\$",tmp[rowtmp[1]+k],perl=TRUE)
   if(alt_format == FALSE) {
      VarScal_pars[i,] = as.numeric(unlist(split_str(trim((tmp[rowtmp+k]))))[1:5])
      i = i + 1
   } else {
      tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp[1]+k])))[2:7])
      for (j in 1:tmp3[1]){
         VarScal_pars[i+j-1,] = tmp3[-1]
      }
      i = i + j
   }
   k = k + 1
   next
}

rowtmp = rowtmp + (k - 1) 

######################################################################
#  Read Catchability PARAMETERS Only if set to be estimated NOT MLE
######################################################################

if (vpa_parameter_est_opt["Estimation of Qs",1] > 0) {
   Catchabil_pars = matrix(NA, ncol=5, nrow=(num_indices*num_years))
   i = k = 1 
   
   while (i <= num_indices*num_years){
      alt_format = grepl("\\$",tmp[rowtmp[1]+k],perl=TRUE)
      if(alt_format == FALSE) {
         Catchabil_pars[i,] = as.numeric(unlist(split_str(trim((tmp[rowtmp+k]))))[1:5])
         i = i + 1
      } else {
         tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp[1]+k])))[2:7])
         for (j in 1:tmp3[1]){
            Catchabil_pars[i+j-1,] = tmp3[-1]
         }
         i = i + j
      }
      k = k + 1
      next
   }
   rowtmp = rowtmp + (k - 1) 
}

#########################################################
#  Read Tagging PARAMETERS Only if using Tagging Data 
#########################################################

#   also ignored tagging data when a "@" is encounter at the 1st line 

if (grepl("@",tmp[rowtmp+1])==FALSE) {
   if(tagg_data == TRUE){

   # Fraction surviving the initiatl tagging process (one line for each age)
      
      TaggInitial_mort = matrix(NA, ncol=5, nrow=(num_ages))
      i = k = 1 
      
      while (i <= num_ages){
         alt_format = grepl("\\$",tmp[rowtmp[1]+k],perl=TRUE)
         if(alt_format == FALSE) {
            TaggInitial_mort[i,] = as.numeric(unlist(split_str(trim((tmp[rowtmp+k]))))[1:5])
            i = i + 1
         } else {
            tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp[1]+k])))[2:7])
            for (j in 1:tmp3[1]){
               TaggInitial_mort[i+j-1,] = tmp3[-1]
            }
            i = i + j
         }
         k = k + 1
         next
      }
      rowtmp = rowtmp + (k - 1) 
   
   # Tag shedding rate (one line for each age)
   
   TagShed_rate = matrix(NA, ncol=5, nrow=(num_ages))
   i = k = 1 
   
   while (i <= num_ages){
      alt_format = grepl("\\$",tmp[rowtmp[1]+k],perl=TRUE)
      if(alt_format == FALSE) {
         TagShed_rate[i,] = as.numeric(unlist(split_str(trim((tmp[rowtmp+k]))))[1:5])
         i = i + 1
      } else {
         tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp[1]+k])))[2:7])
         for (j in 1:tmp3[1]){
            TagShed_rate[i+j-1,] = tmp3[-1]
         }
         i = i + j
      }
      k = k + 1
      next
   }
   rowtmp = rowtmp + (k - 1) 

   # Tag reporting rate (one line for each year)
   
   TagShed_rate = matrix(NA, ncol=5, nrow=(num_years))
   i = k = 1 

   while (i <= num_years){
      alt_format = grepl("\\$",tmp[rowtmp[1]+k],perl=TRUE)
      if(alt_format == FALSE) {
         TagReport_rate[i,] = as.numeric(unlist(split_str(trim((tmp[rowtmp+k]))))[1:5])
         i = i + 1
      } else {
         tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp[1]+k])))[2:7])
         for (j in 1:tmp3[1]){
            TagReport_rate[i+j-1,] = tmp3[-1]
         }
         i = i + j
      }
      k = k + 1
      next
   }
   rowtmp = rowtmp + (k - 1) 
   
   # Tag premixing adjustment first year (one line for each year*age)
   
   TagMix_1st = matrix(NA, ncol=5, nrow=(num_years*num_ages))
   i = k = 1 
   
   while (i <= num_years*num_ages){
      alt_format = grepl("\\$",tmp[rowtmp[1]+k],perl=TRUE)
      if(alt_format == FALSE) {
         TagMix_1st[i,] = as.numeric(unlist(split_str(trim((tmp[rowtmp+k]))))[1:5])
         i = i + 1
      } else {
         tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp[1]+k])))[2:7])
         for (j in 1:tmp3[1]){
            TagMix_1st[i+j-1,] = tmp3[-1]
         }
         i = i + j
      }
      k = k + 1
      next
   }
   rowtmp = rowtmp + (k - 1) 

   # Tag premixing adjustment second year (one line for each year*age)
   
   TagMix_2nd = matrix(NA, ncol=5, nrow=(num_years*num_ages))
   i = k = 1 
   
   while (i <= num_years*num_ages){
      alt_format = grepl("\\$",tmp[rowtmp[1]+k],perl=TRUE)
      if(alt_format == FALSE) {
         TagMix_2nd[i,] = as.numeric(unlist(split_str(trim((tmp[rowtmp+k]))))[1:5])
         i = i + 1
      } else {
         tmp3 = as.numeric(unlist(split_str(trim(tmp[rowtmp[1]+k])))[2:7])
         for (j in 1:tmp3[1]){
            TagMix_2nd[i+j-1,] = tmp3[-1]
         }
         i = i + j
      }
      k = k + 1
      next
   }
   rowtmp = rowtmp + (k - 1) 
   
   }
}



# Combining the VPA initial parameters into a single list .... 

VPA_init_Parameters = list(Terminal_Pars=Par_terminals,F_ratios=Fratio_pars,M_pars=M_pars,Mixing=Mixing_pars,SR_pars=SR_pars,Var_Scaling=VarScal_pars)

if (vpa_parameter_est_opt["Estimation of Qs",1]>0) {
  VPA_init_Parameters[["Catchability"]] = Catchabil_pars }
if (tagg_data == TRUE) {
   Tagg_pars = list(TaggInitial_mort,TagShed_rate,TagShed_rate,TagMix_1st,TagMix_2nd)
   VPA_init_Parameters[["Tagging"]] =  Tagg_pars }













#=================================================================================
#
#     Now read the Output files:  Results  
#
#=================================================================================


if(!file.exists(vpa_files["Results file",])) {
  x = paste("Error VPA Result outpu file doesn't exit, please check name and location.")
  stop(x) }

tmp = readLines(vpa_files["Results file",])
tmp = trim(gsub("\t", " ", tmp, perl = TRUE))
tmp = tmp[nchar(tmp)>0]

Title_run = trim(tmp[5])
tmp2 = unlist(split_str(trim(gsub(",","",tmp[6]))))
tmp2 = paste(tmp2[4],substr(tmp2[3],1,3),tmp2[2],tmp2[1],sep="/")
Date_run = strptime(tmp2,format="%Y/%b/%d/%H:%M")

rowtmp = c(grep("Total objective function",tmp),grep("Out of bounds penalty",tmp))
tmp2 = strsplit(tmp[rowtmp[1]:rowtmp[2]],split="=")
tmp2 = tmp2[lapply(tmp2,length)>0]
tmp3 = unlist(lapply(tmp2,"[[",1))
tmp4 = gsub("\\)","",gsub("\\(","",(lapply(tmp2,"[[",2))))
tmp4 = split_str(trim(tmp4))

Fitting_stast = matrix(NA,nrow=length(tmp3),ncol=2)
row.names(Fitting_stast) = tmp3
Fitting_stast[,1] = as.numeric(unlist(lapply(tmp4,"[[",1))) 
Fitting_stast[grep("\\(",tmp4),2] = as.numeric(unlist(lapply(tmp4[lapply(tmp4,length)>1],"[[",2))) 
rm(tmp4,tmp3,tmp2)


########################################
#  Read Fishing Mortaliy by year-age
########################################

rowtmp = grep("TABLE 1. FISHING MORTALITY RATE",tmp)
rowtmp = c(rowtmp+4,rowtmp+4+num_years-1)

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
tmp2 =  matrix(as.numeric(unlist(split_str(trim(tmp2)))),ncol=num_ages+1,byrow=TRUE)
FAA =  tmp2[,-1]
dimnames(FAA) = list(tmp2[,1],paste("Age",vpa_ages[1]:vpa_ages[2]))

########################################
#  Read Abundance Start Year by year-age
########################################

rowtmp = grep("TABLE 2. ABUNDANCE AT THE BEGINNING OF THE YEAR",tmp)
rowtmp = c(rowtmp[1]+4,rowtmp[1]+4+num_years)

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
tmp3 =  matrix(as.numeric(unlist(split_str(trim(tmp2)))),ncol=num_ages+1,byrow=TRUE)
# always missing the first-age for last-year replace for NA 
tmp3[dim(tmp3)[1],-1] = c(NA,tmp3[dim(tmp3)[1],-c(1,dim(tmp3)[2])])

NAA =  tmp3[,-1]
dimnames(NAA) = list(tmp3[,1],paste("Age",vpa_ages[1]:vpa_ages[2]))

########################################
#  Read Catch at age by year-age
########################################

rowtmp = grep("TABLE 3. CATCH OF",tmp)
rowtmp = c(rowtmp[1]+4,rowtmp[1]+4+num_years-1)

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
tmp3 =  matrix(as.numeric(unlist(split_str(trim(tmp2)))),ncol=num_ages+1,byrow=TRUE)

CAA =  tmp3[,-1]
dimnames(CAA) = list(tmp3[,1],paste("Age",vpa_ages[1]:vpa_ages[2]))

#####################################################
#  Read Spawning Stock Fecundity and Recruitment 
#####################################################

rowtmp = grep("TABLE 4. SPAWNING STOCK FECUNDITY AND RECRUITMENT",tmp)
rowtmp = c(rowtmp[1]+5,rowtmp[1]+5+num_years-1)

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
tmp3 =  matrix(as.numeric(unlist(split_str(trim(tmp2)))),ncol=3,byrow=TRUE)

SSB_Rec = tmp3[,-1]
dimnames(SSB_Rec) = list(tmp3[,1],c("SSB","Rec"))

########################################
#  Read Fits to indices of abundance 
########################################

rowtmp = c(grep("TABLE 5. FITS TO INDEX DATA",tmp),grep("TOTAL NUMBER OF FUNCTION EVALUATIONS",tmp))

tmp2 = tmp[(rowtmp[1]+3):(rowtmp[2]-2)]


# Check from control file which indices are in the data file, report also the non-used ones!

tmp3 = as.data.frame(Index_specification)
row.names(tmp3) = gsub("'","",row.names(tmp3))


tmp3$LogL = NA
tmp3$Deviance = NA
tmp3$Chisq = NA
Index_fit_values = matrix(NA,ncol = 10, nrow = 0)
colnames(Index_fit_values) = c("Index_ID","Year","Obs","Pred","Res","Stdev","Q","ObsUntrs","PredUntrs","Chisq")
Index_select_age = matrix(NA, ncol = (num_ages + 2), nrow= 0)
colnames(Index_select_age) = c("Index_ID","Year", paste("Age",vpa_ages[1]:vpa_ages[2]))

for (i in 1:(num_indices)) {
  
  if(trim(tmp2[(grep(row.names(tmp3)[i],tmp2,fixed=TRUE)+2)])=="Not used") {
    paste("Index not used.")
    next() }
  if(i < num_indices){
    tmp4 = tmp2[grep(row.names(tmp3)[i],tmp2,fixed=TRUE):(grep(row.names(tmp3)[i+1],tmp2,fixed=TRUE)-2)] 
  } else {
    tmp4 = tmp2[grep(row.names(tmp3)[i],tmp2):length(tmp2)] 
  }
  
  #  Get the index fit statistics .
   
  tmp5 = tmp4[1:8]
  tmp5 = strsplit(tmp5,split="=")
  tmp5 = tmp5[lapply(tmp5,length)>1]
  tmp5 = as.numeric(unlist(lapply(tmp5,"[[",2)))
  tmp3$LogL[i] = tmp5[1];tmp3$Deviance[i] = tmp5[2];tmp3$Chisq[i] = tmp5[3]
  
  #  Get the index predicted and observed values fits
  
  tmp5 = tmp4[12:(grep("Selectivities by age",tmp4)-1)]
  tmp5 =  cbind(i,(matrix(as.numeric(unlist(split_str(trim(tmp5)))),ncol=9,byrow=TRUE)))
  Index_fit_values = rbind(Index_fit_values,tmp5)
  
  #  Get the index selectivities by age

  tmp5 = tmp4[(grep("Selectivities by age",tmp4)+1):(length(tmp4))]
  tmpAges = as.numeric(unlist(split_str(trim(tmp5[1])))[-1])
  tmp6 = cbind(i, matrix(as.numeric(unlist(split_str(trim(tmp5[-c(1:2)])))),ncol=(length(tmpAges)+1),byrow=TRUE))
  colnames(tmp6) = c("Index_ID","Year",paste("Age",tmpAges)) 
  tmp5 = matrix(NA, ncol = (num_ages + 2), nrow= dim(tmp6)[1])
  colnames(tmp5) = c("Index_ID","Year", paste("Age",vpa_ages[1]:vpa_ages[2]))
  
  for (j in 1:dim(tmp6)[1]){
    tmp5[j,match(colnames(tmp6),colnames(tmp5))] = tmp6[j,]
    }
  
  Index_select_age = rbind(Index_select_age,tmp5)
  
  rm(tmp4,tmp5,tmp6,tmpAges)
}

Index_fit_stats = tmp3

rm(tmp,tmp2,tmp3,rowtmp)


VPA_results_1 = list(Title=Title_run,Date=Date_run,Fit_stast=Fitting_stast,FAA=FAA,NAA=NAA,CAA=CAA,SSB_Rec=SSB_Rec,
                     Indices=list(Fit_stast=Index_fit_stats,Index_fit=Index_fit_values,Index_Select=Index_select_age))









#=================================================================================
#
#     Now read the Output files:  Estimated Parameters  
#
#=================================================================================

if(!file.exists(vpa_files["Par est file",])) {
  x = paste("Error VPA Parameter estimate output file doesn't exit, please check name and location.")
  stop(x) }

tmp = readLines(vpa_files["Par est file",])
tmp = trim(gsub("\t", " ", tmp, perl = TRUE))
tmp = sub_Dexp(tmp)


# get list of output estimates (read from file records with # and names)

tmp2 = tmp[grep("#",tmp)]
par_estim = trim(gsub("#","",tmp2))
rowtmp = grep("#",tmp)
num_par_est = as.numeric(unlist(strsplit(tmp[max(rowtmp)],split="="))[2])
# get those parameters with flag BOUND 
par_bound = grep("BOUND",tmp)
# replace all numeric 1D-0 or 1D+0 with 1e-0/1eD+



tmp3 = matrix(NA,ncol=8,nrow=length(tmp))
tmp5 = character(length=length(tmp))
tmp6 = as.character(rep(NA,length(tmp)))
# generate variable of the par_estim with flag BOUND
if(length(par_bound) > 0) {
  tmp6[par_bound] = "BOUND"
}

for (i in 1:(length(rowtmp)-1)) {
  for (j in (rowtmp[i]+1):(rowtmp[i+1]-1)) {
    tmp4 = as.numeric(unlist(split_str(trim(tmp[j])))[1:8])
    tmp3[j,1:length(tmp4)] = tmp4
    tmp5[j] = par_estim [i]
  }
}

tmp3 = tmp3[-rowtmp,]; tmp5 = tmp5[-rowtmp]; tmp6 = tmp6[-rowtmp]

par_estim_matrix = data.frame(cbind(data.frame(tmp5,stringsAsFactors = FALSE),data.frame(tmp3),tmp6),stringsAsFactors=FALSE)
names(par_estim_matrix) = c("par_estim","lowb","est","uppb","method","lgstderr","par_ID","Est_ID","CV","Flag")

rm(tmp,tmp2,tmp3,tmp4,tmp5,tmp6)


VPA_results_Par_est = par_estim_matrix[!is.na(par_estim_matrix$Est_ID),]












#======================================================================================
#
#     Now read the Output files:  Boostrap results ONLY IF BOOTSTRAP Option is YES  
#
#======================================================================================


if((vpa_bootstrap["Number boots",1] > 0) & file.exists("BOOTSTRP.OUT")) {
  paste("Reading bootstrap results: ", vpa_bootstrap[1,1])
  
tmp = readLines("BOOTSTRP.OUT")
tmp = trim(gsub("\t", " ", tmp, perl = TRUE))
tmp = sub_Dexp(tmp)
tmp = tmp[nchar(tmp)>0]


#####################################################
#  Read Bias  & std error FAA
#####################################################

rowtmp = grep("TABLE 1A. BIAS OF FISHING MORTALITY RATE",tmp) + 4 
rowtmp = c(rowtmp[1],rowtmp[1]+num_years-1)

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
tmp3 =  matrix(as.numeric(unlist(split_str(trim(tmp2)))),ncol=num_ages+1,byrow=TRUE)

Bias_FAA =  tmp3[,-1]
dimnames(Bias_FAA) = list(tmp3[,1],paste("Age",vpa_ages[1]:vpa_ages[2]))

rowtmp = grep("TABLE 1B. STANDARD ERROR OF FISHING MORTALITY RATE",tmp) + 4 
rowtmp = c(rowtmp[1],rowtmp[1]+num_years-1)

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
tmp3 =  matrix(as.numeric(unlist(split_str(trim(tmp2)))),ncol=num_ages+1,byrow=TRUE)

Stderr_FAA =  tmp3[,-1]
dimnames(Stderr_FAA) = list(tmp3[,1],paste("Age",vpa_ages[1]:vpa_ages[2]))

#####################################################
#  Read Bias  & std error Abundance NAA
#####################################################

rowtmp = grep("TABLE 1C. BIAS OF ABUNDANCE",tmp) + 4 
rowtmp = c(rowtmp[1],rowtmp[1]+num_years)

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
tmp3 =  matrix(as.numeric(unlist(split_str(trim(tmp2[-length(tmp2)])))),ncol=num_ages+1,byrow=TRUE)
#  read the next to last year at start abundance, minus the 1st age
tmp4 = as.numeric(unlist(split_str(trim(tmp2[length(tmp2)]))))
tmp4 = c(tmp4[1],NA,tmp4[-1])
tmp3 = rbind(tmp3,tmp4)

Bias_NAA =  tmp3[,-1]
dimnames(Bias_NAA) = list(tmp3[,1],paste("Age",vpa_ages[1]:vpa_ages[2]))

rowtmp = grep("TABLE 1D. STANDARD ERROR OF ABUNDANCE",tmp) + 4 
rowtmp = c(rowtmp[1],rowtmp[1]+num_years)

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
tmp3 =  matrix(as.numeric(unlist(split_str(trim(tmp2[-length(tmp2)])))),ncol=num_ages+1,byrow=TRUE)
#  read the next to last year at start abundance, minus the 1st age
tmp4 = as.numeric(unlist(split_str(trim(tmp2[length(tmp2)]))))
tmp4 = c(tmp4[1],NA,tmp4[-1])
tmp3 = rbind(tmp3,tmp4)

Stderr_NAA =  tmp3[,-1]
dimnames(Stderr_NAA) = list(tmp3[,1],paste("Age",vpa_ages[1]:vpa_ages[2]))

########################################################
#  Read Parameter estimates of bootstraped results
########################################################

rowtmp = c(grep("TABLE 1E. PARAMETER ESTIMATES",tmp),grep("CORRELATION AND COVARIANCE MATRICES OF PARAMETERS",tmp)) 

tmp2 = tmp[(rowtmp[1]+3):(rowtmp[2]-5)]
tmp2 = tmp2[nchar(tmp2)>3]
tmp2 = tmp2[-grep("---",tmp2)]
tmp3 = c(grep("TERMINAL AGE STRUCTURE OF POPULATION ABUNDANCE",tmp2),grep("TERMINAL AGE STRUCTURE OF FISHING MORTALITY RATE",tmp2),grep("RATIO OF FISHING MORTALITY RATE",tmp2),grep("NATURAL MORTALITY RATE",tmp2),grep("TRANSFER COEFFICIENTS",tmp2),grep("VARIANCE SCALING PARAMETERS",tmp2),grep("CATCHABILITY COEFFICIENTS",tmp2))

par_estim_boot = trim(tmp2[tmp3])
par_estim_boot_matrix = list(NA)

# reading only the numeric lines ...
for (i in 1:(length(tmp3))) {
   if (i!=length(tmp3)){m <- (tmp3[i+1]-1)
      } else { m <- length(tmp2) }
     localtmp = length(as.numeric(unlist(split_str(trim(tmp2[tmp3[i]+3])))))
     tmp4 = matrix(as.numeric(unlist(split_str(trim(tmp2[(tmp3[i]+3):m])))),ncol=localtmp,nrow=length((tmp3[i]+3):m),byrow = TRUE)
   par_estim_boot_matrix[[i]] = tmp4  
   names(par_estim_boot_matrix)[[i]] = par_estim_boot[i]
}
   
############################################################
#  Read CORRELATION AND COVARIANCE MATRICES OF PARAMETERS
############################################################

rowtmp = c(grep("TABLE 2A. CORRELATION MATRIX",tmp),grep("TABLE 2B. COVARIANCE MATRIX",tmp)) 

tmp2 = tmp[(rowtmp[1]+2):(rowtmp[2]-1)]

tmpvals = grep("\\:",tmp2)
tmphead = range(as.numeric(unlist(split_str(trim(tmp2[-tmpvals])))))
corr_matrix = matrix(NA,ncol=tmphead[2],nrow=tmphead[2])

tmp3 = (strsplit((tmp2[tmpvals]),split="\\:"))
tmp4 = as.numeric(unlist(lapply(tmp3,"[[",1)))
tmp5 = c(1,grep(max(tmphead),tmp4))
tmp6 = as.list(c(rep(c(NA),max(tmphead))))


for(i in 1:(length(tmp5)-1)) {
   for (j in tmp5[i]:tmp5[i+1]){
      tmp6[[(tmp4[j])]][i] = tmp3[[j]][2]
   }
}
   
for(i in 1:dim(corr_matrix)[1]){
   localtmp = as.numeric(unlist(split_str(trim(tmp6[[i]]))))
   corr_matrix[i,1:length(localtmp)] = localtmp
}
   
rowtmp = c(grep("TABLE 2B. COVARIANCE MATRIX",tmp),length(tmp)) 

tmp2 = tmp[(rowtmp[1]+2):(rowtmp[2])]

tmpvals = grep("\\:",tmp2)
tmphead = range(as.numeric(unlist(split_str(trim(tmp2[-tmpvals])))))
covar_matrix = matrix(NA,ncol=tmphead[2],nrow=tmphead[2])

tmp3 = (strsplit((tmp2[tmpvals]),split="\\:"))
tmp4 = as.numeric(unlist(lapply(tmp3,"[[",1)))
tmp5 = c(1,grep(max(tmphead),tmp4))
tmp6 = as.list(c(rep(c(NA),max(tmphead))))

for(i in 1:(length(tmp5)-1)) {
   for (j in tmp5[i]:tmp5[i+1]){
      tmp6[[(tmp4[j])]][i] = tmp3[[j]][2]
   }
}

for(i in 1:dim(corr_matrix)[1]){
   localtmp = as.numeric(unlist(split_str(trim(tmp6[[i]]))))
   covar_matrix[i,1:length(localtmp)] = localtmp
}


VPA_boots_results = list(FAA=list(Bias=Bias_FAA,Stderr=Stderr_FAA),NAA=list(Bias=Bias_NAA,Stderr=Stderr_NAA),Corr=corr_matrix,Cov=covar_matrix,Par_estimates = par_estim_boot_matrix)

}







#======================================================================================
#
#     Now read the Output files:  Boostrap binary files ONLY IF BOOTSTRAP Option is YES  
#
#======================================================================================

if((vpa_bootstrap["Number boots",1] > 0) & file.exists("CAA.OUT")) {
   paste("Reading bootstrap results: ", vpa_bootstrap[1,1])

bin_files = c("NAA.OUT","FAA.OUT","CAA.OUT","MAA.OUT","TAA.OUT","IND.OUT","TERM.OUT","SR.OUT")
boot_files = as.list(rep(as.numeric(NA),8))
names(boot_files) = c(paste(substr(bin_files,1,3),"_boot_matrix",sep=""))
ncols = (num_years)*(num_ages)*vpa_n_zones
nobs = ncols*(vpa_bootstrap["Number boots",1]+1)

for(i in 1:length(bin_files)){
   if(!file.exists(bin_files[i])){
      print(paste("NOTE VPA Boot output file doesn't exist: ",bin_files[i]))
   next()  } 

   # reading the first 5 boot files ... NAA to TAA
   if  (i < 6) {
   tmp =  readBin(bin_files[i], double(),n=floor(nobs*1.2),size=4)
   boot_files[[i]] = matrix(tmp,ncol=ncols,nrow=nobs/ncols,byrow=TRUE)
   rm(tmp)   
   } else if (i == 6) {

# reading the index boot output file ..
   
   tmp = readBin(bin_files[i], double(), n=((num_years)*(num_indices)*(vpa_bootstrap["Number boots",1]+1)),size=4)
   boot_files[[i]] = matrix(tmp,ncol=((num_years)*(num_indices)),nrow=(vpa_bootstrap["Number boots",1]+1),byrow=TRUE)
   rm(tmp)
   } else if (i == 7) {

# reading the terminal vulnerabilities  (last year) boot ....
   
   tmp = readBin(bin_files[i], double(), n=((num_ages)*(vpa_n_zones)*(vpa_bootstrap["Number boots",1]+1)),size=4)
   boot_files[[i]] = matrix(tmp,ncol=((num_ages)*(vpa_n_zones)),nrow=(vpa_bootstrap["Number boots",1]+1),byrow=TRUE)   
   rm(tmp)
   } else {
      
# reading the Stock-Recruitment boot file ....
      
   tmp = readBin(bin_files[i], double(), n=((5+num_years)*(vpa_n_zones)*(vpa_bootstrap["Number boots",1]+1)), size=4)  
   boot_files[[i]] = matrix(tmp,ncol=((5+num_years)*(vpa_n_zones)),nrow=(vpa_bootstrap["Number boots",1]+1),byrow=TRUE)
   rm(tmp)
   }
}

#  Reading the BAD boot runs and eliminating this from the boot files .

if((vpa_bootstrap["Number boots",1] > 0) & file.exists("BAD.OUT")) {
   paste("Reading BAD bootstraps : ")

tmp = readLines("BAD.OUT")
tmp2 = as.vector(0)
if(length(tmp)>1) {
   for (i in 1:length(tmp)-1){
   tmp2[i] = as.numeric(unlist(split_str(trim(tmp[1:(length(tmp)-1)])))[1])
   }}

num_bad_boots = length(tmp2)-1
vpa_bad_boots = tmp2
}

if (num_bad_boots > 0){
for (i in 1:length(boot_files)) {
   if(is.matrix(boot_files[[i]])) {
   boot_files[[i]] = boot_files[[i]][-vpa_bad_boots,]
   } else {
      next
      } }
}
   
}  else {
   x = paste("\n No Bootstrap runs \n ")
   cat(x) 
}











#======================================================================================
#
#     Now read the Output files: VPA-2BOX.LOG file  
#
#======================================================================================


if(file.exists("VPA-2BOX.LOG")) {
  
tmp = readLines("VPA-2BOX.LOG")
tmp = trim(gsub("\t", " ", tmp, perl = TRUE))
tmp = sub_Dexp(tmp)
tmp = tmp[nchar(tmp)>0]

vpa_log_values = as.list(c(rep(c(NA),6)))
names(vpa_log_values) = c("Initial OBJ Function","Amoeba restarts","First deriv test","Hessian Matrix","Corr Matrix","Cov Matrix")

vpa_log_values[["Initial OBJ Function"]] = as.numeric(unlist(strsplit(tmp[grep("Initial value of the OBJECTIVE function",tmp)],split="="))[2])

tmp2 = strsplit(tmp[grep("Amoeba restart",tmp)],split="=")
vpa_log_values[["Amoeba restarts"]] = as.numeric(unlist(lapply(tmp2,"[[",2)))

rowtmp = c((grep("FIRST DERIVATIVE TEST",tmp)+4),(grep("HESSIAN MATRIX",tmp)-1))
tmp2 = trim(tmp[rowtmp[1]:rowtmp[2]])
tmp2 = lapply(strsplit((tmp[rowtmp[1]:rowtmp[2]]),split="\\:"),"[[",-1)
tmp2 = as.numeric(gsub("D","e",unlist(split_str(unlist(lapply(tmp2,trim))))))
vpa_log_values[["First deriv test"]] = matrix(tmp2,ncol=3,byrow = TRUE)
dimnames(vpa_log_values[["First deriv test"]]) = list(c(paste("Par_",seq(1:(rowtmp[2]-rowtmp[1]+1)))),c("-h","central","+h"))

#  read Hessian matrix 


rowtmp = c((grep("HESSIAN MATRIX",tmp)+2),(grep("CORRELATION MATRIX",tmp)-1))
tmp2 = tmp[(rowtmp[1]):(rowtmp[2])]
tmpvals = grep("\\:",tmp2)
tmphead = range(as.numeric(unlist(split_str(trim(tmp2[-tmpvals])))))
Hess_matrix = matrix(NA,ncol=tmphead[2],nrow=tmphead[2])

tmp3 = (strsplit((tmp2[tmpvals]),split="\\:"))
tmp4 = as.numeric(unlist(lapply(tmp3,"[[",1)))
tmp5 = c(1,grep(max(tmphead),tmp4))
tmp6 = as.list(c(rep(c(NA),max(tmphead))))


for(i in 1:(length(tmp5)-1)) {
   for (j in tmp5[i]:tmp5[i+1]){
      tmp6[[(tmp4[j])]][i] = tmp3[[j]][2]
   }
}

for(i in 1:dim(Hess_matrix)[1]){
   localtmp = as.numeric(unlist(split_str(trim(tmp6[[i]]))))
   Hess_matrix[i,1:length(localtmp)] = localtmp
}

vpa_log_values[["Hessian Matrix"]] = Hess_matrix

rm(Hess_matrix,tmp2,tmp3,tmp4,tmp5,tmp6)

#  read correlation matrix 

rowtmp = c((grep("CORRELATION MATRIX",tmp)+2),(grep("COVARIANCE MATRIX",tmp)-1))
tmp2 = tmp[(rowtmp[1]):(rowtmp[2])]
tmpvals = grep("\\:",tmp2)
tmphead = range(as.numeric(unlist(split_str(trim(tmp2[-tmpvals])))))
Corrlog_matrix = matrix(NA,ncol=tmphead[2],nrow=tmphead[2])

tmp3 = (strsplit((tmp2[tmpvals]),split="\\:"))
tmp4 = as.numeric(unlist(lapply(tmp3,"[[",1)))
tmp5 = c(1,grep(max(tmphead),tmp4))
tmp6 = as.list(c(rep(c(NA),max(tmphead))))


for(i in 1:(length(tmp5)-1)) {
   for (j in tmp5[i]:tmp5[i+1]){
      tmp6[[(tmp4[j])]][i] = tmp3[[j]][2]
   }
}

for(i in 1:dim(Corrlog_matrix)[1]){
   localtmp = as.numeric(unlist(split_str(trim(tmp6[[i]]))))
   Corrlog_matrix[i,1:length(localtmp)] = localtmp
}

vpa_log_values[["Corr Matrix"]] = Corrlog_matrix

rm(Corrlog_matrix,tmp2,tmp3,tmp4,tmp5,tmp6)


#  read covariance matrix 

rowtmp = c((grep("COVARIANCE MATRIX",tmp)+2),(grep("DETERMINISTIC",tmp)-1))
tmp2 = tmp[(rowtmp[1]):(rowtmp[2])]
tmpvals = grep("\\:",tmp2)
tmphead = range(as.numeric(unlist(split_str(trim(tmp2[-tmpvals])))))
Covlog_matrix = matrix(NA,ncol=tmphead[2],nrow=tmphead[2])

tmp3 = (strsplit((tmp2[tmpvals]),split="\\:"))
tmp4 = as.numeric(unlist(lapply(tmp3,"[[",1)))
tmp5 = c(1,grep(max(tmphead),tmp4))
tmp6 = as.list(c(rep(c(NA),max(tmphead))))


for(i in 1:(length(tmp5)-1)) {
   for (j in tmp5[i]:tmp5[i+1]){
      tmp6[[(tmp4[j])]][i] = tmp3[[j]][2]
   }
}

for(i in 1:dim(Covlog_matrix)[1]){
   localtmp = as.numeric(unlist(split_str(trim(tmp6[[i]]))))
   Covlog_matrix[i,1:length(localtmp)] = localtmp
}

vpa_log_values[["Cov Matrix"]] = Covlog_matrix

rm(Covlog_matrix,tmp2,tmp3,tmp4,tmp5,tmp6)

} else {
   x = paste("Error VPA-2BOX log file does not exist Please check ")
   stop(x) 
}


#=================================================================================
#
#     Now read the Output files:  Retrospective files/run  
#
#=================================================================================


if(vpa_gen_settings[["Retrospective"]][1] != "No") {
   x = paste("Retrospective runs, reading output files \n ",
             "It will look for files in the current directory :\n",
             dirVPA)
   cat(x) 

#=================================================================================
#      Reading retropspective Results (Minus#.r) files  
#=================================================================================

#   Creating a list object to store the Retro results;

retro_list_names <- paste0("Retro",(1:vpa_gen_settings[["Retrospective"]][2]))
vpa_retro_results <- sapply(retro_list_names, function(x) NA)
items <- c("FitStats","FAA","NAA","SSB_Rec","EstPar")
items <- sapply(items,function(x) NULL)
tmp <- lapply(vpa_retro_results, function(x) items)

vpa_retro_results = tmp

for (retro in 1:(vpa_gen_settings[["Retrospective"]][2]))  {
   if(!file.exists(paste0("MINUS",retro,".R"))) {
      x = paste("Error Retro output file: \n", paste0("MINUS",retro,".R"), "\n doesn't exit, please check name and location.")
      stop(x) }

tmp = readLines(paste0("MINUS",retro,".R"))
tmp = trim(gsub("\t", " ", tmp, perl = TRUE))

rowtmp = c(grep("Total objective function",tmp),grep("Out of bounds penalty",tmp))
tmp2 = strsplit(tmp[rowtmp[1]:rowtmp[2]],split="=")
tmp2 = tmp2[lapply(tmp2,length)>0]
tmp3 = unlist(lapply(tmp2,"[[",1))
tmp4 = gsub("\\)","",gsub("\\(","",(lapply(tmp2,"[[",2))))
tmp4 = split_str(trim(tmp4))

vpa_retro_results[[retro]]$FitStats = matrix(NA,nrow=length(tmp3),ncol=2)
row.names(vpa_retro_results[[retro]]$FitStats) = tmp3
vpa_retro_results[[retro]]$FitStats[,1] = as.numeric(unlist(lapply(tmp4,"[[",1))) 
vpa_retro_results[[retro]]$FitStats[grep("\\(",tmp4),2] = as.numeric(unlist(lapply(tmp4[lapply(tmp4,length)>1],"[[",2))) 
rm(tmp4,tmp3,tmp2)


########################################
#  Read Fishing Mortaliy by year-age
########################################

rowtmp = grep("TABLE 1. FISHING MORTALITY RATE",tmp)
rowtmp = c(rowtmp[1]+4,rowtmp[1]+4+num_years-1-retro)

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
tmp2 =  matrix(as.numeric(unlist(split_str(trim(tmp2)))),ncol=num_ages+1,byrow=TRUE)
vpa_retro_results[[retro]]$FAA =  tmp2[,-1]
dimnames(vpa_retro_results[[retro]]$FAA) = list(tmp2[,1],paste("Age",vpa_ages[1]:vpa_ages[2]))

########################################
#  Read Abundance Start Year by year-age
########################################

rowtmp = grep("TABLE 2. ABUNDANCE AT THE BEGINNING OF THE YEAR",tmp)
rowtmp = c(rowtmp[1]+5,rowtmp[1]+5+num_years-retro)

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
tmp3 =  matrix(as.numeric(unlist(split_str(trim(tmp2)))),ncol=num_ages+1,byrow=TRUE)
# always missing the first-age for last-year replace for NA 
tmp3[dim(tmp3)[1],-1] = c(NA,tmp3[dim(tmp3)[1],-c(1,dim(tmp3)[2])])

vpa_retro_results[[retro]]$NAA =  tmp3[,-1]
dimnames(vpa_retro_results[[retro]]$NAA) = list(tmp3[,1],paste("Age",vpa_ages[1]:vpa_ages[2]))


#####################################################
#  Read Spawning Stock Fecundity and Recruitment 
#####################################################

rowtmp = grep("TABLE 4. SPAWNING STOCK FECUNDITY AND RECRUITMENT",tmp)
rowtmp = c(rowtmp[1]+5,rowtmp[1]+5+num_years-1-retro)

tmp2 = tmp[rowtmp[1]:rowtmp[2]]
tmp3 =  matrix(as.numeric(unlist(split_str(trim(tmp2)))),ncol=3,byrow=TRUE)

vpa_retro_results[[retro]]$SSB_Rec = tmp3[,-1]
dimnames(vpa_retro_results[[retro]]$SSB_Rec) = list(tmp3[,1],c("SSB","Rec"))

#=================================================================================
#     Now read retrospective Estimated Parameters file 
#=================================================================================

tmp = readLines(paste0("MINUS",retro,".EST"))
tmp = trim(gsub("\t", " ", tmp, perl = TRUE))

# get list of output estimates (read from file records with # and names)

tmp2 = tmp[grep("#",tmp)]
par_estim = trim(gsub("#","",tmp2))
rowtmp = grep("#",tmp)
num_par_est = as.numeric(unlist(strsplit(tmp[max(rowtmp)],split="="))[2])
# get those parameters with flag BOUND 
par_bound = grep("BOUND",tmp)
# replace all numeric 1D-0 or 1D+0 with 1e-0/1eD+
tmp  = gsub("D","e",tmp)


tmp3 = matrix(NA,ncol=8,nrow=length(tmp))
tmp5 = character(length=length(tmp))
tmp6 = as.character(rep(NA,length(tmp)))
# generate variable of the par_estim with flag BOUND
if(length(par_bound) > 0) {
   tmp6[par_bound] = "BOUND"
}

for (i in 1:(length(rowtmp)-1)) {
   for (j in (rowtmp[i]+1):(rowtmp[i+1]-1)) {
      tmp4 = as.numeric(unlist(split_str(trim(tmp[j])))[1:8])
      tmp3[j,1:length(tmp4)] = tmp4
      tmp5[j] = par_estim [i]
   }
}

tmp3 = tmp3[-rowtmp,]; tmp5 = tmp5[-rowtmp]; tmp6 = tmp6[-rowtmp]

tmp <- data.frame(cbind(data.frame(tmp5,stringsAsFactors = FALSE),data.frame(tmp3),tmp6),stringsAsFactors=FALSE)
names(tmp) = c("par_estim","lowb","est","uppb","method","lgstderr","par_ID","Est_ID","CV","Flag")
tmp <- tmp[tmp$method==1,]
vpa_retro_results[[retro]]$EstPar <- tmp

rm(tmp,tmp2,tmp3,tmp4,tmp5,tmp6)

      }
   }  else {
   x = paste("No Retrospective runs ")
   cat(x) 
}

if(vpa_gen_settings[["Retrospective"]][1] != "No" & vpa_gen_settings[["Retrospective"]][2] > 0) {

   #  Adding to the vpa_retro_results the corresponding objects for the MLE run (e.g. retro = 0)
   
   vpa_retro_results[["Retro0"]] = list(FitStats=VPA_results_1$Fit_stast,FAA=VPA_results_1$FAA,
                                        NAA=VPA_results_1$NAA,SSB_Rec=VPA_results_1$SSB_Rec,
                                        EstPar=VPA_results_Par_est)
}


##########################################################
#   cleaning and organizing r objects
##########################################################

rm (i,j,k,m,tmp,tmpc,tmphead,tmpvals,rowtmp,localtmp)
rm(alt_format,counter,ncols,nobs)

##########################################################
#   group together the results to pass an object back
##########################################################

if(vpa_gen_settings[["Bootstrap"]][1] == "Yes") {
  boots = list(VPA_boots_results=VPA_boots_results,vpa_bootstrap=vpa_bootstrap,boot_files=boot_files)
} else {
  boots = NA
}

if(vpa_gen_settings[["Retrospective"]][1] != "No"){
  retrosp = list(vpa_retro_results=vpa_retro_results)
} else {
  retrosp = NA
}

ResultsVPA = list(vpa_gen_settings=vpa_gen_settings,vpa_constrainst=vpa_constrainst,vpa_Files=vpa_Files,Vpa_Inputs=Vpa_Inputs,
                  Vpa_Inp_Matrices=Vpa_Inp_Matrices,VPA_init_Parameters=VPA_init_Parameters,VPA_results_1=VPA_results_1,
                  VPA_results_Par_est=VPA_results_Par_est,vpa_log_values=vpa_log_values,Otbl_1=Otbl_1,Otbl_2=Otbl_2,Otbl_2A=Otbl_2A,
         boots=boots, retrosp=retrosp,Index_names=Index_names,num_indices=num_indices,vpa_years=vpa_years,num_ages=num_ages,
         vpa_ages=vpa_ages,num_years=num_years)
         

}

