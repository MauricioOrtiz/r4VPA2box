

make_Vpa_Plots <- function(What=What,dirVPA,vpa_ctl,vpa_results,...) {

  vpa_gen_settings = vpa_results[["vpa_gen_settings"]]
  Vpa_Inp_Matrices=vpa_results[["Vpa_Inp_Matrices"]]
  FecAA_matrix = vpa_results[["Vpa_Inp_Matrices"]]$Fecundity
  maturity_age = vpa_results[["Vpa_Inputs"]]$Maturity
  spawn_season = vpa_results[["Vpa_Inputs"]]$Spawn_season
  Index_names = vpa_results[["Index_names"]]
  num_indices = vpa_results[["num_indices"]]
  num_ages = vpa_results[["num_ages"]]
  vpa_ages = vpa_results[["vpa_ages"]]
  num_years = vpa_results[["num_years"]]
  Vpa_Inputs = vpa_results[["Vpa_Inputs"]]
  vpa_years = vpa_results[["vpa_years"]]
  VPA_results_1 = vpa_results[["VPA_results_1"]]
  VPA_results_Par_est = vpa_results[["VPA_results_Par_est"]]
  vpa_log_values = vpa_results[["vpa_log_values"]]
  if(vpa_gen_settings[["Bootstrap"]][1] == "Yes") {
    VPA_boots_results = vpa_results[["boots"]]$VPA_boots_results
    vpa_bootstrap = vpa_results[["boots"]]$vpa_bootstrap
    boot_files =  vpa_results[["boots"]]$boot_files   }
  if(vpa_gen_settings[["Retrospective"]][1] == "Yes") {
    vpa_retro_results = vpa_results[["retrosp"]][[1]]}


#  Plot input data and biological input data

#     CAA input

df <- data.frame(Vpa_Inp_Matrices[["CAA"]])
df$Year = as.numeric(row.names.data.frame(df))
df = tidyr::gather(df,"Age","Ns",starts_with("Age"))
df$Age = factor((as.numeric(gsub("Age.","",df$Age))))
getPalette = colorRampPalette(brewer.pal(9, "Set1"))

Oplot_1 <- ggplot(df,aes(x=Year,y=Ns,group=rev(Age))) + geom_bar(aes(fill=(Age)),stat="identity") + scale_fill_manual(values=getPalette(num_ages),name="Age") + ylab("CAA numbers of fish") + theme(legend.position = "bottom") + guides(fill=guide_legend(nrow=2))

Oplot_2 <- ggplot(df,aes(x=Year,y=Ns,group=rev(Age))) + geom_bar(aes(fill=(Age)),stat="identity",position = "fill") + scale_fill_manual(values=getPalette(num_ages),name="Age") + ylab("% CAA by year") + theme(legend.position = "bottom") + guides(fill=guide_legend(nrow=2))


#  Weigth at age input for indices (only if units = 2 biomass)

df <- data.frame(Vpa_Inp_Matrices[["WAA"]])
if (dim(df)[1] > 0) {
   df = unite(df,key,Index_ID, Year, sep="_")
   df = tidyr::gather(df,"Age","WAAs",starts_with("Age"))
   df = separate(df,key,c("Index_ID","Year"),sep="_")
   df$Age = as.numeric(gsub("Age.","",df$Age))
   df$Year = as.numeric(df$Year)
   tmp <- data.frame(Index_name=Index_names,Index_ID=seq(1:num_indices),stringsAsFactors = FALSE)
   df <- merge(tmp,df)
   WAA_plots = list(rep(NULL,length(unique(df$Index_ID))))

for (i in 1:length(unique(df$Index_ID))){
   tmp = df[df$Index_ID == unique(df$Index_ID)[i],]
   tmp2 = ggplot(tmp,aes(x=Year,y=WAAs)) + geom_line(aes(color=as.factor(Age)),show.legend=TRUE,size=0.8) + xlab("Year") + ylab("Weight at age") + ggtitle(Index_names[unique(df$Index_ID)][i])
   #print(tmp2)
   WAA_plots[[i]] = tmp2
   names(WAA_plots)[[i]] = paste0("WAA_",Index_names[unique(df$Index_ID)][i])
   assign(paste0("Oplot_3",letters[i]), tmp2)
}}

#  Fecundity at age input

df <- data.frame(Vpa_Inp_Matrices[["Fecundity"]])
df = tidyr::gather(df,"Age","Fecundity",starts_with("Age"))
df$Age = factor((as.numeric(gsub("Age.","",df$Age))))

Oplot_4 <- ggplot(df,aes(x=Year,y=Fecundity,group=rev(Age))) + geom_line(aes(color=Age),show.legend=TRUE,size=0.8) + xlab("Year") + ylab("Weight at age") + ggtitle("Fecundity at age")

#  Maturity at age input

df <- data.frame(Maturity = Vpa_Inputs[["Maturity"]])
df$Age = as.numeric(gsub("Age ","",row.names.data.frame(df)))

Oplot_5 <- ggplot(df, aes(x=Age,y=Maturity)) + geom_line(color='darkgreen',size=1.3) + ggtitle("Maturity at age")


#  Available indices and years for each index.

df <- data.frame(Vpa_Inp_Matrices[["Index"]]$Values)
df$Year = seq(vpa_years[1],vpa_years[2])
df = tidyr::gather(df,"Index_ID","value",starts_with("X"))
df$Index_ID = as.numeric(gsub("X","",df$Index_ID))
tmp <- data.frame(Index_name=Index_names,Index_ID=seq(1:num_indices),stringsAsFactors = FALSE)
df = merge(tmp,df)


df = df[!is.na(df$value),]
Oplot_6 <- ggplot(df,aes(x=Index_name,y=Year,group=Index_name)) + geom_point(aes(color=Index_name),show.legend=F,size=3) + coord_flip() + xlab("")+ ylab("") + ggtitle("Input indices of abundance by year VPA2-Box")

tmp = aggregate(df$value,by=list(df$Index_ID),FUN=mean)
names(tmp) = c("Index_ID","scl_value")
df = merge(df,tmp)
df$scl_value = df$value/df$scl_value

Oplot_7 <- ggplot(df,aes(x=Year,y=scl_value,group=Index_name)) + geom_line(aes(color=Index_name),size=0.8) + ylab("Scaled index value to their mean for each series") + ggtitle ("Indices trends input VPA2-Box")

# plot indices with CV inputs

tmp <- data.frame(Vpa_Inp_Matrices[["Index"]]$CV)
tmp$Year = seq(vpa_years[1],vpa_years[2])
tmp = tidyr::gather(tmp,"Index_ID","CV",starts_with("X"))
tmp$Index_ID = as.numeric(gsub("X","",tmp$Index_ID))

df = dplyr::left_join(df,tmp,by=c("Index_ID","Year"))
df$low = qnorm(0.05,mean=df$scl_value,sd=df$scl_value*df$CV)
df$hig = qnorm(0.95,mean=df$scl_value,sd=df$scl_value*df$CV)

Oplot_8 <- ggplot(df,aes(x=Year,y=scl_value,group=Index_name)) + geom_ribbon(aes(ymin=low,ymax=hig,fill=Index_name)) + geom_line(size=0.8,show.legend = F) + ylab("Scaled index value to their mean for each series") + ggtitle ("Indices trends input VPA2-Box with 90% CI") + facet_wrap(~ Index_name)


# plot indices: Plot indices stats

df <- VPA_results_1[["Indices"]]$Fit_stast
names(df) = gsub(" ","_",names(df))
Otbl_3 <- datatable(df,filter="top",options=list(pageLength=20,autoWidth=FALSE))
df = df[complete.cases(df),]
df$IndexName = row.names.data.frame(df)
df$ccolor = as.factor(df$Index_ID)


Oplot_9 <- ggplot(df,aes(x=IndexName,y=LogL,fill=IndexName)) + geom_bar(stat='identity',show.legend = F) + theme(axis.text.x=element_text(angle=90,hjust=1,vjust = 0.5) ) + ylab("log likelihood") + xlab("") + coord_flip()

Oplot_9a <- qplot(x=IndexName, y=LogL,data=df,xlab="",ylab="log likelihood. Size proportional deviance", size= Deviance,colour=ccolor,show.legend=FALSE) + coord_flip()

#  plot indices: by index

df <- as.data.frame(VPA_results_1[["Indices"]]["Index_fit"])
tmp <- VPA_results_1[["Indices"]]$Fit_stast$`Index ID`
tmp2 <- row.names.data.frame(VPA_results_1[["Indices"]]$Fit_stast)
tmp <- data.frame(Index_fit.Index_ID=tmp,Index=I(tmp2))
df <- merge(tmp,df)

# plot indices: obs,pred by year-index

Oplot_10 <- ggplot(df,aes(x=Index_fit.Year,y=Index_fit.Obs)) + geom_point(aes(color=as.factor(Index_fit.Index_ID)),show.legend=FALSE) + geom_line(aes(y=Index_fit.Pred),size=1.25) + xlab("Year") + ylab("Value") + facet_wrap(~ Index)

# plot indices: residuals in up-down

Oplot_10a <- ggplot(df,aes(x=Index_fit.Year,y=Index_fit.Res)) + geom_point(aes(color=as.factor(Index_fit.Index_ID)),show.legend=FALSE) + geom_linerange(aes(ymin=0,ymax=Index_fit.Res)) + geom_hline(yintercept = 0, linetype=2) + xlab("Year") + ylab("Residual") + facet_wrap(~Index)

# plot indices: Chisq by index

Oplot_10b <- ggplot(df,aes(x=Index_fit.Year,y=Index_fit.Chisq)) + geom_point(aes(color=as.factor(Index_fit.Index_ID)),show.legend=FALSE) + geom_linerange(aes(ymin=0,ymax=Index_fit.Chisq)) + xlab("Year") + ylab("Chisq") + facet_wrap(~Index)

# plot indices: Obs vrs Pred with linear fit

Oplot_10c <- ggplot(df,aes(x=Index_fit.Obs,y=Index_fit.Pred)) + geom_point(aes(color=as.factor(Index_fit.Index_ID)),show.legend=FALSE) + geom_smooth(method = 'lm', se=FALSE, colour='black') + xlab("Observed") + ylab("Predicted") + facet_wrap(~Index)

#  Plot selectivity by index, year-age

df <- as.data.frame(VPA_results_1[["Indices"]]["Index_Select"])
names(df) = gsub("Index_Select.","",names(df))
names(df) = gsub("\\.","",names(df))

df = unite(df,key,Index_ID,Year,sep="_")
df = gather(df,"Age","Sel",starts_with("Age"))
df = separate(df,key,c("Index_ID","Year"),sep="_")
df$Age = as.numeric(gsub("Age","",df$Age))
df$Year = as.numeric(df$Year)
tmp <- data.frame(Index_name=Index_names,Index_ID=seq(1:num_indices),stringsAsFactors = FALSE)
df <- merge(tmp,df)
df = df[!is.na(df$Sel),]

Oplot_11 <- ggplot(df,aes(x=Age,y=Sel)) + geom_line(aes(color=as.factor(Index_name)),show.legend=TRUE) + xlab("Age") + ylab("Selectivity") + facet_wrap(~ Year)

#==============================================================
#   Plots SSB_Rec
#==============================================================

df <- as.data.frame(VPA_results_1[["SSB_Rec"]])
df$Year = as.numeric(row.names.data.frame(df))
Otbl_4 <- datatable(df,options=list(pageLength=50,autoWidth=TRUE),style="Bootstrap",rownames=FALSE)

Oplot_12 <- ggplot(df,aes(x=Year,y=SSB)) + geom_line(colour="darkblue",show.legend = F) + theme_gray()

Oplot_12a <- ggplot(df,aes(x=Year,y=Rec,colour=2)) + geom_line(colour="orange",show.legend = F) + theme_gray()

Oplot_12b <- ggplot(df,aes(x=SSB,y=Rec,color=Year)) + geom_point(size=4) + scale_color_gradientn(colours=rainbow(12))

text = paste0("Correlation SSB Rec : ",round(with(df, cor(SSB,Rec)),digits=4))

Oplot_12c <- ggplot(df,aes(x=Year,y=scale(SSB))) + geom_line(colour="darkblue",show.legend = F) + geom_line(aes(y=scale(Rec)),colour="red") + ylab("Z scores SSB (blue) and Rec (red)") + annotate("text", x=mean(df$Year),y=0.5*max(scale(df$Rec)),label=text) + theme_gray()

#==============================================================
#   Plots CAA
#==============================================================

df <- as.data.frame(VPA_results_1[["CAA"]])
df$Total <- apply(df,1,sum,na.rm=T)
df$Year <- as.numeric(row.names.data.frame(df))
Otbl_5 <- datatable(df[,-dim(df)[2]],options=list(dom='t',pageLength=50,autoWidth=TRUE),style="Bootstrap",
                    caption = "Table 5: Input CAA")


df2 <- as.data.frame(Vpa_Inp_Matrices[["CAA"]])
df2$Total <- apply(df2,1,sum,na.rm=T)
df2$Year <- as.numeric(row.names.data.frame(df2))


Oplot_13 <- ggplot(df,aes(x=Year,y=Total)) + geom_line(colour="navy",show.legend = F,linetype = 1) + geom_point(data=df2,size=3,color='red') + ylab("Total CAA N fish input(dot) output(line)") + theme_gray()


#==============================================================
#   Plots FAA
#==============================================================

df <- as.data.frame(VPA_results_1[["FAA"]])
df$Year = as.numeric(row.names.data.frame(df))
Otbl_6 <- datatable(df[,-dim(df)[2]],options=list(dom='t',pageLength=50,autoWidth=TRUE),style="Bootstrap",
                    caption = "Table 6: Estimated FAA ")

df <- tidyr::gather(df,"Age","Fs",1:(dim(df)[2]-1))
df$tmp = as.numeric(gsub("Age ","",df$Age))
df = df[order(df$tmp,df$Year),]
df$Cohort = df$Year-df$tmp
# plot FAA year-age



Oplot_14 <- ggplot(df,aes(x=Year,y=Fs,color=Age)) + geom_line(size=1.25,show.legend = F) + xlab("Year") + ylab("Fishing mortality") + facet_wrap(~ tmp)

Oplot_14a <- ggplot(df,aes(x=Year,y=tmp,size=Fs,colour=as.factor(Cohort))) + geom_point(show.legend = F) + ylab("Fishing Mortality at age") + theme_dark()


#==============================================================
#   Plots NAA
#==============================================================

df <- as.data.frame(VPA_results_1[["NAA"]])
df$Year = as.numeric(row.names.data.frame(df))
Otbl_7 <- datatable(df[,-dim(df)[2]],options=list(dom='t',pageLength=50,autoWidth=TRUE),style="Bootstrap",
                    caption = "Table 7: Estimated NAA")

df <- tidyr::gather(df,"Age","Ns",1:(dim(df)[2]-1))
df$tmp = as.numeric(gsub("Age ","",df$Age))
df = df[order(df$tmp,df$Year),]
df$Cohort = df$Year-df$tmp
# plot NAA year-age

Oplot_15 <- ggplot(df,aes(x=Year,y=Ns,color=Age)) + geom_line(size=1.25,show.legend = F) + xlab("Year") + ylab("Numbers of fish") + facet_wrap(~ tmp,scales="free_y",strip.position = "bottom") #+ theme(strip.background = element_blank(),strip.placement = "outside")

Oplot_15a <- ggplot(df,aes(x=Year,y=tmp,size=Ns,colour=as.factor(Cohort))) + geom_point(show.legend = F) + ylab("Number fish at age") + theme_dark()

#==============================================================
#   Plot Parameter estimates
#==============================================================

df <- as.data.frame(VPA_results_Par_est)
df = df[,-c(5,7,8)]
Otbl_8 <- datatable(df,options=list(dom='t',pageLength=50,autoWidth=FALSE),style="default",rownames=FALSE,
                    caption="Table 8: Estimated parameters in run")

df$par_id = as.numeric(ave(df$par_estim,df$par_estim,FUN=seq_along))

Oplot_16 <- ggplot(df,aes(x=par_id,y=est,color=as.factor(par_estim))) + geom_point(size=3,show.legend = F) + facet_wrap(~ par_estim,scales="free_y")

#  Plot the first derivative test results

df <- as.data.frame(vpa_log_values[["First deriv test"]])
names(df) = c("low","central","high")
df$par = as.numeric(sub("Par_","",row.names(df)))
df = df[order(df$par),]


ggplot(df,aes(x=par,y=central,ymin=low,ymax=high)) + geom_crossbar() + coord_flip()

# plot correlation matrix from the log file (same plot in the bootstrap ...)

df <- t(vpa_log_values[["Corr Matrix"]])
dimnames(df) = list(paste0("Par_",(1:dim(df)[1])),paste0("Par_",(1:dim(df)[1])))
df <- melt(df,na.rm=TRUE)
ggplot(df,aes(Var2, Var1,fill=value)) + geom_tile(color="white") + scale_fill_gradient2(low="blue",high="red",mid="white",midpoint = 0,limit=c(-1,1),space="Lab",name="Pearson\n Corr") + theme_minimal() + theme(axis.text.x = element_text(angle=45, vjust = 1,size=10, hjust = 1)) + labs(x=NULL,y=NULL)+ coord_fixed()



###########################################################################################################


#==============================================================
#   Plots Bootstrapped results
#==============================================================

if(vpa_gen_settings[["Bootstrap"]][1] == "Yes") {

names(VPA_boots_results)

# plot FAA bias/stderr year-age

df<- as.data.frame(VPA_boots_results[["FAA"]]$Stderr)
df$Year = as.numeric(row.names.data.frame(df))
Otbl_9 <- datatable(df[,-dim(df)[2]],options=list(dom='t',pageLength=50,autoWidth=FALSE),style="Bootstrap",
                    caption = "Table 9: FAA stderr bootstrap estimated")

df <- tidyr::gather(df,"Age","FAAstderr",1:(dim(df)[2]-1))
df$tmp = as.numeric(gsub("Age ","",df$Age))
df = df[order(df$tmp,df$Year),]

Oplot_17 <- ggplot(df,aes(x=Year,y=tmp,size=FAAstderr,colour=as.factor(Age))) + geom_point(show.legend = F) + ylab("FAA stderr at age") + theme_dark()


# plot NAA bias/stderr year-age

df<- as.data.frame(VPA_boots_results[["NAA"]]$Stderr)
df$Year = as.numeric(row.names.data.frame(df))
Otbl_10 <- datatable(df[,-dim(df)[2]],options=list(dom='t',pageLength=50,autoWidth=FALSE),style="Bootstrap",
                     caption = "Table 10: NAA Stderr bootstrap estimated")

df <- tidyr::gather(df,"Age","NAAstderr",1:(dim(df)[2]-1))
df$tmp = as.numeric(gsub("Age ","",df$Age))
df = df[order(df$tmp,df$Year),]

Oplot_18 <- ggplot(df,aes(x=Year,y=tmp,size=NAAstderr,colour=as.factor(Age))) + geom_point(show.legend = F) + ylab("NAA stderr at age") + theme_dark()

# plot Correlation matrix

df<- (VPA_boots_results[["Corr"]])
upperTriangle(df) = lowerTriangle(df)
Oplot_19 <- corrplot(df, method="color", type="upper",order="hclust")

# show the Hessian matrix   #  need to review how to present this .....

df<- (vpa_log_values[["Hessian Matrix"]])
upperTriangle(df) = lowerTriangle(df)
Otbl_11 <- datatable(df,options=list(dom='t',autowide=FALSE,pageLength=50),style="Bootstrap",
                     caption = "Table 11: Hessian matrix")
df.m <- melt(df)

Oplot_20 <- ggplot(df.m, aes(x=Var1,y=Var2, fill=value)) + geom_tile() + scale_fill_gradient(low="blue",high = "red")


#  Working with the boots of FAA, NAA SSB and Indices to show trends with confidence bounds....


names(boot_files)
lapply(boot_files,class)
lapply(boot_files,dim)


#     NAA MLE, and 10, 50, 90 percentiles ....

df <- boot_files[["NAA_boot_matrix"]]
tmp = t(apply(df[-1,],2,quantile,probs = c(0.10,0.50,0.90),na.rm=TRUE,type=8))
tmp2 = rep(seq(vpa_years[1],vpa_years[2]),num_ages)
tmp3 = rep(seq(vpa_ages[1],vpa_ages[2]),each=num_years)
df = data.frame(Year=tmp2,Age=tmp3,MLE=df[1,],tmp)

Oplot_21 <- ggplot(df,aes(x=Year,y=MLE)) + geom_line(size=1.25,show.legend = F) + geom_line(aes(y=X10.,color='blue')) + geom_line(aes(y=X50.,color='blue')) + geom_line(aes(y=X90.,color='blue')) + xlab("Year") + ylab("Numbers of fish") + facet_wrap(~ Age,scales="free_y",strip.position = "bottom")

Oplot_21a <- ggplot(df,aes(x=Year,y=MLE)) + geom_ribbon(aes(ymin=X10.,ymax=X90.),fill="yellow") + geom_line(size=0.8,show.legend = F) + xlab("Year") + ylab("Numbers of fish") + facet_wrap(~ Age,scales="free_y",strip.position = "bottom")
# violin plots of bootstraps last 10 yrs only

df <- t(boot_files[["NAA_boot_matrix"]])
df = data.frame(Year=tmp2,Age=tmp3,df)
df = df[df$Year >= (vpa_years[2]-10),]
df = unite(df,key,Age, Year, sep="_")
df = tidyr::gather(df,"boot","Ns",starts_with("X"))
df = separate(df,key,c("Age","Year"),sep="_")
df$Age = as.numeric(df$Age)

Oplot_21b <- ggplot(df,aes(x=Year,y=Ns,fill=as.factor(Age))) + geom_violin(scale="area",na.rm=TRUE,show.legend=F) + facet_wrap(~ Age,scales="free_y")

# estimate SSB for boots using NAA and Fec*Mat vectors / adjusted to spawning time equ 3.12 vpa2-box manual

x = t(FecAA_matrix[,-1])*maturity_age
x = t(x)
z = (boot_files[["FAA_boot_matrix"]] + boot_files[["MAA_boot_matrix"]])*(spawn_season/12)
y = t(boot_files[["NAA_boot_matrix"]]*exp(-z))
tmp = y*as.numeric(x)
colnames(tmp) = paste("B",seq(0,(dim(tmp)[2]-1),by=1),sep="")
tmp = data.frame(cbind(Year=tmp2,Age=tmp3,tmp))
tmp = tmp %>% dplyr::group_by(Year) %>% dplyr::summarise_all(sum)
tmp = t(tmp[,-2])

df <- tmp[-1,]
tmp = t(apply(df[-1,],2,quantile,probs = c(0.10,0.50,0.90),na.rm=TRUE,type=8))/1000
df = data.frame(Year=as.numeric(row.names(VPA_results_1[["SSB_Rec"]])),MLE=VPA_results_1[["SSB_Rec"]][,1],tmp)

Oplot_21b <- ggplot(df,aes(x=Year,y=MLE)) + geom_line(size=1.25,show.legend = F) + geom_line(aes(y=X10.,color='blue')) + geom_line(aes(y=X50.,color='blue')) + geom_line(aes(y=X90.,color='blue')) + xlab("Year") + ylab("SSB t")

Oplot_21c <- ggplot(df,aes(x=Year,y=MLE)) + geom_ribbon(aes(ymin=X10.,ymax=X90.),fill="orange") + geom_line(size=0.8,show.legend = F) + xlab("Year") + ylab("SSB t")


#     FAA MLE, and 10, 50, 90 percentiles ....

df <- boot_files[["FAA_boot_matrix"]]
tmp = t(apply(df[-1,],2,quantile,probs = c(0.10,0.50,0.90),na.rm=TRUE,type=8))

df = data.frame(Year=tmp2,Age=tmp3,MLE=df[1,],tmp)

Oplot_22 <- ggplot(df,aes(x=Year,y=MLE)) + geom_line(size=1.25,show.legend = F) + geom_line(aes(y=X10.)) + geom_line(aes(y=X50.)) + geom_line(aes(y=X90.)) + xlab("Year") + ylab("Fishing mortality") + facet_wrap(~ Age,scales="free_y",strip.position = "top")

Oplot_22a <- ggplot(df,aes(x=Year,y=MLE)) + geom_ribbon(aes(ymin=X10.,ymax=X90.),fill="orange") + geom_line(color="darkblue",size=0.8,show.legend = F) + xlab("Year") + ylab("Fishing mortality") + facet_wrap(~ Age,scales="free_y",strip.position = "top")

# violin plots of bootstraps last 10 yrs only

df <- t(boot_files[["FAA_boot_matrix"]])
df = data.frame(Year=tmp2,Age=tmp3,df)
df = df[df$Year >= (vpa_years[2]-10),]
df = unite(df,key,Age, Year, sep="_")
df = tidyr::gather(df,"boot","Fs",starts_with("X"))
df = separate(df,key,c("Age","Year"),sep="_")
df$Age = as.numeric(df$Age)

Oplot_22b <- ggplot(df,aes(x=Year,y=Fs,fill=as.factor(Age))) + geom_violin(scale="area",na.rm=TRUE,show.legend=F) + facet_wrap(~ Age,scales="free_y")

#   Indices boots

df <- boot_files[["IND_boot_matrix"]]
tmp = t(apply(df[-1,],2,quantile,probs = c(0.10,0.50,0.90),na.rm=TRUE,type=8))
tmp2 = rep(seq(vpa_years[1],vpa_years[2]),num_indices)
tmp3 = rep(seq(1,num_indices),each=num_years)
df = data.frame(Year=tmp2,Index_ID=tmp3,MLE=df[1,],tmp)
df = df[!is.na(df$MLE),]
df = df[df$MLE>0,]

tmp <- data.frame(Index_name=Index_names,Index_ID=seq(1:num_indices),stringsAsFactors = FALSE)
df = merge(tmp,df)

Oplot_23 <- ggplot(df,aes(x=Year,y=MLE)) + geom_ribbon(aes(ymin=X10.,ymax=X90.),fill="pink") + geom_line(aes(y=X50.),color="darkred",show.legend = F) + geom_line(color="purple",size=0.8,show.legend = F) + xlab("Year") + ylab("Index fit") + facet_wrap(~ Index_name,scales="free_y",strip.position = "top")

} else {

   x = paste("Boostrap results r object NOT FOUND \n",
             "No plots of boostrap runs generated \n")
   cat(x);
}


###########################################################################################################

#==============================================================
#   Plots Retrospective runs results
#==============================================================

if(vpa_gen_settings[["Retrospective"]][1] == "Yes") {

   # plot SSB and Rec ts trends

   tmp <- lapply(vpa_retro_results,"[[","SSB_Rec")
   tmp <- lapply(tmp,function(x) cbind(x,Year=as.numeric(row.names(x))))
   tmp <- lapply(tmp,function(x) as.data.frame(x))
   ID <- names(tmp)
   tmp <- mapply(cbind,tmp,"Retro"=ID,SIMPLIFY = F,stringsAsFactors=F)
   tmp <- dplyr::bind_rows(tmp)

   Oplot_24 <- ggplot(tmp,aes(x=Year,y=SSB,group=Retro)) + geom_line(aes(color=Retro),size=0.8) + ylab("SSB") + ggtitle ("SSB trends retrospective runs")

   Oplot_24a <- ggplot(tmp,aes(x=Year,y=Rec,group=Retro)) + geom_line(aes(color=Retro),size=0.8) + ylab("Rec") + ggtitle ("Rec trends retrospective runs")


   # plot Fit stats trends

   tmp <- lapply(vpa_retro_results,"[[","FitStats")
   tmp <- lapply(tmp,function(x) as.data.frame(x))
   tmp <- lapply(tmp,function(x) cbind(x,Stats=(row.names(x))))
   tmp <- mapply(cbind,tmp,"Retro"=ID,SIMPLIFY = F,stringsAsFactors=F)
   tmp <- dplyr::bind_rows(tmp)
   names(tmp)[1:2] = c("logL","Stderr")

   Oplot_25 <- ggplot(tmp,aes(x=Retro,y=logL,color=Retro)) + geom_point(size=3,show.legend = F) +labs(x=NULL) + facet_wrap(~ Stats,scales="free_y") + theme(axis.text.x = element_text(angle = 90,hjust = 1))

   #  plot estimated parameters trends
   tmp <- lapply(vpa_retro_results,"[[","EstPar")
   tmp <- lapply(tmp,function(x) as.data.frame(x))
   tmp <- mapply(cbind,tmp,"Retro"=ID,SIMPLIFY = F,stringsAsFactors=F)
   tmp <- dplyr::bind_rows(tmp)

   Oplot_26 <- ggplot(tmp,aes(x=Est_ID,y=est,shape=Retro,color=Retro)) + geom_point(show.legend = T) + facet_wrap(~ par_estim,scales="free_y")

   # plot NAA / FAA trends

   tmp <- lapply(vpa_retro_results,"[[","NAA")
   tmp <- lapply(tmp,function(x) cbind(x,Year=as.numeric(row.names(x))))
   tmp <- lapply(tmp,function(x) as.data.frame(x))
   ID <- names(tmp)
   tmp <- mapply(cbind,tmp,"Retro"=ID,SIMPLIFY = F,stringsAsFactors=F)
   tmp <- dplyr::bind_rows(tmp)
   df <- tidyr::gather(tmp,"Age","Ns",starts_with("Age"))
   df$tmp = as.numeric(gsub("Age ","",df$Age))
   df = df[order(df$tmp,df$Year),]

   Oplot_27 <- ggplot(df,aes(x=Year,y=Ns,color=Retro,group=Retro)) + geom_line(show.legend = T) + xlab("Year") + ylab("Numbers of fish") + facet_wrap(~ tmp,scales="free_y",strip.position = "bottom") #+ theme(strip.background = element_blank(),strip.placement = "outside")

   tmp <- lapply(vpa_retro_results,"[[","FAA")
   tmp <- lapply(tmp,function(x) cbind(x,Year=as.numeric(row.names(x))))
   tmp <- lapply(tmp,function(x) as.data.frame(x))
   ID <- names(tmp)
   tmp <- mapply(cbind,tmp,"Retro"=ID,SIMPLIFY = F,stringsAsFactors=F)
   tmp <- dplyr::bind_rows(tmp)
   df <- tidyr::gather(tmp,"Age","Fs",starts_with("Age"))
   df$tmp = as.numeric(gsub("Age ","",df$Age))
   df = df[order(df$tmp,df$Year),]

   Oplot_28 <- ggplot(df,aes(x=Year,y=Fs,color=Retro,group=Retro)) + geom_line(show.legend = T) + xlab("Year") + ylab("Fishing mortality") + facet_wrap(~ tmp,scales="free_y",strip.position = "top")

}  else {

   x = paste("Retrospective results r object NOT FOUND \n",
             "No plots of retrospective runs generated \n")
   cat(x);}


#==============================================================
#   make an export object of plots and tables ....
#==============================================================


  createdirplots(What)
  pwidth = 6.5;pheight=5;punits="in";psize=10;res=300;

  tmp = ls(pattern="Oplot_")
  tmp = mget(tmp)
  names(tmp) = ls(pattern="Oplot_")
  Tab_plots = Tables_plots()[[2]]
  for (i in 1:length(tmp)){
    j = match(names(tmp)[i],Tab_plots[,1])
    tmp2 = paste0("./plots/",Tab_plots[j,2],".png")
    png(filename=tmp2,width=pwidth,height=pheight,units=punits,pointsize=psize,res=res)
    plot(tmp[[i]])
    dev.off()
  }
  # save tables as html widgets in the directory ./plots also
  tmp = ls(pattern="Otbl_")
  tmp = mget(tmp)
  names(tmp) = ls(pattern="Otbl_")
  Tab_tables = Tables_plots()[[1]]
  setwd("./plots")
  for (i in 1:length(tmp)){
    j = match(names(tmp)[i],Tab_tables[,1])
    tmp2 = paste0(Tab_tables[j,2],'.html')
    saveWidget(tmp[[i]],tmp2)
  }
  setwd("..")
}  # end of function

