####################################################################################
#
#  Functions extra of the VPA2-Box results data input reading ..
#     Mao 2017
#
####################################################################################


#==================================  functions =========================================
#' Trimming data lines
#'
#' Removes white spaces from beginning and end of lines
#' @param x An string character vector
#' @return string character vector withouth ahead or trailing spaces
#' @export
#' trim()
trim <- function( x ) {
   gsub("(^[[:space:]]+|[[:space:]]+$)", "", x)
}

#' Split a string vector
#'
#' Takes a stringer vector and splitted when find a white space within
#' @param x A string character vector
#' @return A list of strings
#' @export
#' split_str()
split_str <- function(x){
   strsplit(x, "\\s{1,}")
}

#' Creates a folder called "plots" to store Tables and graphics created by r4VPA2box
#'
#' Creastes folder plots under the data directory
#' @param NULL no parameter input required
#' @return directory plots
#' @export
#' create_plots_dir()
create_plots_dir <- function(){
   mainDir = getwd()
   subDir = "plots"
   ifelse(!dir.exists(file.path(mainDir,subDir)), dir.create(file.path(mainDir, subDir)),FALSE)
}

#' Replaces scientific nomenclature 00D+ exponent for 00E+ exponent
#'
#' Searches in a list of string vector for D+ or D- scientific exponent and replaces with E+ or E- exponent
#' @param x a list of string vector(s)
#' @return a list of string vector(s) with replaced D+ notation for E+ notation
#' @export
#' @examples
#' sub_Dexp()
sub_Dexp <- function(x){
   gsub("D+","E+",gsub("D-","E-",x,fixed=TRUE),fixed=TRUE)
}

# Examples
#' Run a given example of VPA 2 box results and shows in html format
#'
#' Present a list of available examples of VPA2 box runs to user.
#' @param x NULL
#' @return a list of string vector with control file and folder of example data
#' @export
#' run_example()
run_example <- function(){
  Exam = menu(c("1 ALB example from Toolbox","2 BFT-E example SA 2017 SCRS newBFT ratios","3 BFT-W example SA 2017 SCRS","4 BFT-E retrospective 10 yrs","5 BFT-W Boots SA 2017 SCRS"))
  y = Example_r4VPA2box(Exam)
  return(y)
}

# Run my own data
#' Run my own data of VPA 2 box results and show in html format
#'
#' User choose the control file and the function will summarize the data results and present in html format
#' @param  NULL
#' @return after user file control selection a list of the file and folder data for processing
#' @export@
#' @examples
#' run_mydata()
run_mydata <- function(){
  if (interactive())
    x <- choose.files(caption = "Select VPA2Box control file:", multi = FALSE)
  x = gsub("\\","/",x,fixed=TRUE)
  vpa_ctl = substr(x,start=(max(unlist(gregexpr("/",x,fixed=TRUE)))+1),stop=nchar(x))
  dirVPA = substr(x,start=1,stop=(max(unlist(gregexpr("/",x,fixed=TRUE)))-1))
  y = c(dirVPA,vpa_ctl)
  return(y)
}

# Load the libraries required for the r4VPA2box
getlibraries <- function(What=1){
  if(What>=1 & What<=2) {
    library(DT)
    library(dplyr)
    library(tidyr)
    library(reshape2)
    library(xtable)
    library(corrplot)
    library(gdata)
    library(knitr)
    library(ggplot2)
    library(RColorBrewer)
  } else {
    stop("Not clear what to do ....")
  }
}
#
# Create a folder plots under the data folder where tables and plots are stored
#' Create directory plots
#'
#' Create a directory plots and store graphs and tables, if is example only, it will deleter prior folder
#' @param What An integer where 1 example, 2 own data
#' @return create a directory
#' @export
#' @examples
#' createdirplots()
createdirplots <- function(What=What) {

  if(dir.exists(file.path(getwd(),"plots")) & What !=1){
    stop("There is already a subdirectory 'Plots' in this folder \n",
         "   Please check and remove it if you want to overwrite it.")
  } else {
    if(What == 1 & dir.exists(file.path(getwd(),"plots"))) {
      unlink("plots",recursive=TRUE,force=TRUE)
      create_plots_dir()
    } else {
      create_plots_dir() } }
}
#
#' Create dataframe results
#'
#' Create a dataframe with the title, date and version of the VPA run
#' @param Date_run date formated value read from results file,
#'        vpa_version VPA2box version used,
#'        Titlerun  User defined title of the run
#' @return replist report list object with information
#' @export
#' @examples
#' create_df_results
#' ()
create_df_results <- function(Date_run,vpa_version,Titlerun) {
  Tab_tables = Tables_plots()[[1]]
  Tab_plots = Tables_plots()[[2]]
  tmp <- list.files(path="./plots")
  tmp2 <- substr(tmp,start=1, stop=(regexpr("\\.",tmp)-1))
  tmp <- paste0("plots/",tmp)
  tmp3 <- Tab_tables[match(tmp2,Tab_tables[,2]),c(3,4)]
  tmp3 <- ifelse(is.na(tmp3),Tab_plots[match(tmp2,Tab_plots[,2]),c(3,4)],tmp3)
  plotInfoTable <- data.frame(file=tmp,caption=tmp3[,1],category=tmp3[,2],Run_time=Date_run,png_time=Sys.time(),stringsAsFactors=TRUE)
  plotInfoTable = plotInfoTable[order(plotInfoTable$category,plotInfoTable$caption),]
  plotInfoTable = plotInfoTable[!is.na(plotInfoTable$category),]

  replist = list(VPA2Box_ver=vpa_version,Date_run=Date_run,Title_run=Titlerun,Nwarnings=NA,warnings = NA)

  csvname = paste(getwd(),"/plots/","plotInfoTable",".csv",sep="")
  write.csv(plotInfoTable, csvname,row.names=FALSE)
  cat("\n Wrote table of info on PNG files to:\n  ",csvname,"\n")

  return(replist)
}
#
#' run r4vpa2box functions
#
#' It will run the r4vpa2box script and functions asking for the control file
#' @param NULL no parameter input required
#' @return html page with plots and table results of VPA run
#' @export
#' r4vpa2box()
r4vpa2box <- function() {
     What = menu(c("1 Run an example","2 Run own data"))

     if(What == 1) {
          y = run_example()
          dirVPA <- unlist(y)[1]
          vpa_ctl <- unlist(y)[2]
     } else {
          y = run_mydata()
          dirVPA <- unlist(y)[1]
          vpa_ctl <- unlist(y)[2]
     }
     setwd(dirVPA)
     #getlibraries(What)
     vpa_results =  CodeGetVPA2box(dirVPA = dirVPA,vpa_ctl = vpa_ctl)
     vpa_plots = make_Vpa_Plots(What=What,dirVPA = dirVPA,vpa_ctl = vpa_ctl,vpa_results=vpa_results)
     replist = create_df_results(Date_run=vpa_results[["VPA_results_1"]]$Date,vpa_version=vpa_results[["vpa_Files"]]$VPA2BOX_ver,Titlerun=vpa_results[["vpa_Files"]]$vpa_files[1])

     VPA2Box_html(replist = replist)
}
