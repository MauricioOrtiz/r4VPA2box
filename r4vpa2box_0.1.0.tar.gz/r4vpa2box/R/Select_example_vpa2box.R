#'  Examples r4VPA2Box
#'  
#'  Set of VPA2box runs and results plotted with r package.
#'  @param Exam
#'  @return Directory and control file name of example selected
#'  @export
Example_r4VPA2box <- function(x) {
  if(!is.numeric(x)) {
    y = paste("Error:choose an integer number of example0.")
    stop(y) }
  if(x>5 | x<1) {
    y = paste("Error:choose a number between 1 and 5.")
    stop(y) 
  }
  
  Examples_vpa2box = list(NA)

# Exercise 1 use ALB example from Toolbox 
Examples_vpa2box[[1]] =
  list(dirVPA = c("./Examples/ALBexm"),
       vpa_ctl = c("ALB00.C01"))

# Exercise 2 use BFT-E example SA 2017 SCRS plenary/newBFT ratios version 
Examples_vpa2box[[2]] =
  list(dirVPA = c("./Examples/BFTEast"),
       vpa_ctl = c("bfte2017.c1"))

# Exercise 3 use BFT-W example SA 2017 SCRS  
Examples_vpa2box[[3]] =
  list(dirVPA = c("./Examples/BFTWest"),
       vpa_ctl = c("BFTW2017.C01"))

# Exercise 4 use BFT-E retrospective 10 yrs
Examples_vpa2box[[4]] =
  list(dirVPA = c("./Examples/BFTE_ret"),
       vpa_ctl = c("bfte2017.c1"))

# Exercise 5 use BFT-W Boots SA 2017 SCRS
Examples_vpa2box[[5]] =
  list(dirVPA = c("./Examples/BFTW_boot"),
       vpa_ctl = c("BFTW2017.C01"))

return(Examples_vpa2box[[x]])
}

